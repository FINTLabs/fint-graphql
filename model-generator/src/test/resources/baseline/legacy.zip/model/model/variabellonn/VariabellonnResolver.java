
package no.fint.graphql.model.model.variabellonn;

import graphql.schema.DataFetchingEnvironment;
import no.fint.graphql.model.model.arbeidsforhold.ArbeidsforholdService;
import no.fint.graphql.model.model.lonnsart.LonnsartService;
import no.fint.graphql.model.model.personalressurs.PersonalressursService;
import no.novari.fint.model.resource.Link;
import no.novari.fint.model.resource.administrasjon.kodeverk.LonnsartResource;
import no.novari.fint.model.resource.administrasjon.personal.ArbeidsforholdResource;
import no.novari.fint.model.resource.administrasjon.personal.PersonalressursResource;
import no.novari.fint.model.resource.administrasjon.personal.VariabellonnResource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.graphql.data.method.annotation.SchemaMapping;
import org.springframework.stereotype.Controller;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.concurrent.CompletionStage;

@Controller("modelVariabellonnResolver")
public class VariabellonnResolver {

    @Autowired
    private LonnsartService lonnsartService;

    @Autowired
    private ArbeidsforholdService arbeidsforholdService;

    @Autowired
    private PersonalressursService personalressursService;


    @SchemaMapping(typeName = "Variabellonn", field = "lonnsart")
    public CompletionStage<LonnsartResource> getLonnsart(VariabellonnResource variabellonn, DataFetchingEnvironment dfe) {
        return Flux.fromStream(variabellonn.getLonnsart()
                .stream()
                .map(Link::getHref)
                .map(l -> lonnsartService.getLonnsartResource(l, dfe)))
                .flatMap(Mono::flux)
                .next()
                .toFuture();
    }

    @SchemaMapping(typeName = "Variabellonn", field = "arbeidsforhold")
    public CompletionStage<ArbeidsforholdResource> getArbeidsforhold(VariabellonnResource variabellonn, DataFetchingEnvironment dfe) {
        return Flux.fromStream(variabellonn.getArbeidsforhold()
                .stream()
                .map(Link::getHref)
                .map(l -> arbeidsforholdService.getArbeidsforholdResource(l, dfe)))
                .flatMap(Mono::flux)
                .next()
                .toFuture();
    }

    @SchemaMapping(typeName = "Variabellonn", field = "anviser")
    public CompletionStage<PersonalressursResource> getAnviser(VariabellonnResource variabellonn, DataFetchingEnvironment dfe) {
        return Flux.fromStream(variabellonn.getAnviser()
                .stream()
                .map(Link::getHref)
                .map(l -> personalressursService.getPersonalressursResource(l, dfe)))
                .flatMap(Mono::flux)
                .next()
                .toFuture();
    }

    @SchemaMapping(typeName = "Variabellonn", field = "konterer")
    public CompletionStage<PersonalressursResource> getKonterer(VariabellonnResource variabellonn, DataFetchingEnvironment dfe) {
        return Flux.fromStream(variabellonn.getKonterer()
                .stream()
                .map(Link::getHref)
                .map(l -> personalressursService.getPersonalressursResource(l, dfe)))
                .flatMap(Mono::flux)
                .next()
                .toFuture();
    }

    @SchemaMapping(typeName = "Variabellonn", field = "attestant")
    public CompletionStage<PersonalressursResource> getAttestant(VariabellonnResource variabellonn, DataFetchingEnvironment dfe) {
        return Flux.fromStream(variabellonn.getAttestant()
                .stream()
                .map(Link::getHref)
                .map(l -> personalressursService.getPersonalressursResource(l, dfe)))
                .flatMap(Mono::flux)
                .next()
                .toFuture();
    }

}

