
package no.fint.graphql.model.model.kontrakt;

import graphql.schema.DataFetchingEnvironment;
import lombok.extern.slf4j.Slf4j;
import no.novari.fint.model.resource.administrasjon.kodeverk.KontraktResource;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import reactor.core.publisher.Mono;

import java.util.concurrent.CompletionStage;

@Controller("modelKontraktQueryResolver")
@Slf4j
public class KontraktQueryResolver {

    @Autowired
    private KontraktService service;

    public CompletionStage<KontraktResource> kontrakt(
            String systemId,
            DataFetchingEnvironment dfe) {
		log.info("New Query for Kontrakt");
        if (StringUtils.isNotEmpty(systemId)) {
            return service.getKontraktResourceById("systemid", systemId, dfe).toFuture();
        }
        return Mono.<KontraktResource>empty().toFuture();
    }
}
