
package no.fint.graphql.model.model.otstatus;

import graphql.schema.DataFetchingEnvironment;
import lombok.extern.slf4j.Slf4j;
import no.novari.fint.model.resource.utdanning.kodeverk.OtStatusResource;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import reactor.core.publisher.Mono;

import java.util.concurrent.CompletionStage;

@Controller("modelOtStatusQueryResolver")
@Slf4j
public class OtStatusQueryResolver {

    @Autowired
    private OtStatusService service;

    public CompletionStage<OtStatusResource> otstatus(
            String systemId,
            DataFetchingEnvironment dfe) {
		log.info("New Query for OtStatus");
        if (StringUtils.isNotEmpty(systemId)) {
            return service.getOtStatusResourceById("systemid", systemId, dfe).toFuture();
        }
        return Mono.<OtStatusResource>empty().toFuture();
    }
}
