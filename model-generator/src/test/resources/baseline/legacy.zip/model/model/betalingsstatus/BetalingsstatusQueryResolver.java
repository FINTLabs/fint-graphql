
package no.fint.graphql.model.model.betalingsstatus;

import graphql.schema.DataFetchingEnvironment;
import lombok.extern.slf4j.Slf4j;
import no.novari.fint.model.resource.utdanning.kodeverk.BetalingsstatusResource;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import reactor.core.publisher.Mono;

import java.util.concurrent.CompletionStage;

@Controller("modelBetalingsstatusQueryResolver")
@Slf4j
public class BetalingsstatusQueryResolver {

    @Autowired
    private BetalingsstatusService service;

    public CompletionStage<BetalingsstatusResource> betalingsstatus(
            String systemId,
            DataFetchingEnvironment dfe) {
		log.info("New Query for Betalingsstatus");
        if (StringUtils.isNotEmpty(systemId)) {
            return service.getBetalingsstatusResourceById("systemid", systemId, dfe).toFuture();
        }
        return Mono.<BetalingsstatusResource>empty().toFuture();
    }
}
