
package no.fint.graphql.model.model.eksamensvurdering;

import graphql.schema.DataFetchingEnvironment;
import lombok.extern.slf4j.Slf4j;
import no.novari.fint.model.resource.utdanning.vurdering.EksamensvurderingResource;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.stereotype.Controller;
import reactor.core.publisher.Mono;

import java.util.concurrent.CompletionStage;

@Controller("modelEksamensvurderingQueryResolver")
@Slf4j
public class EksamensvurderingQueryResolver {

    @Autowired
    private EksamensvurderingService service;

    @QueryMapping(name = "eksamensvurdering")
    public CompletionStage<EksamensvurderingResource> eksamensvurdering(
            @Argument("systemId") String systemId,
            DataFetchingEnvironment dfe) {
		log.info("New Query for Eksamensvurdering");
        if (StringUtils.isNotEmpty(systemId)) {
            return service.getEksamensvurderingResourceById("systemid", systemId, dfe).toFuture();
        }
        return Mono.<EksamensvurderingResource>empty().toFuture();
    }
}
