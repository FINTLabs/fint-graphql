
package no.fint.graphql.model.model.anlegg;

import graphql.schema.DataFetchingEnvironment;
import lombok.extern.slf4j.Slf4j;
import no.novari.fint.model.resource.administrasjon.kodeverk.AnleggResource;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import reactor.core.publisher.Mono;

import java.util.concurrent.CompletionStage;

@Controller("modelAnleggQueryResolver")
@Slf4j
public class AnleggQueryResolver {

    @Autowired
    private AnleggService service;

    public CompletionStage<AnleggResource> anlegg(
            String systemId,
            DataFetchingEnvironment dfe) {
		log.info("New Query for Anlegg");
        if (StringUtils.isNotEmpty(systemId)) {
            return service.getAnleggResourceById("systemid", systemId, dfe).toFuture();
        }
        return Mono.<AnleggResource>empty().toFuture();
    }
}
