
package no.fint.graphql.model.model.halvarsfagvurdering;

import graphql.schema.DataFetchingEnvironment;
import no.fint.graphql.model.model.elevvurdering.ElevvurderingService;
import no.fint.graphql.model.model.fag.FagService;
import no.fint.graphql.model.model.karakterverdi.KarakterverdiService;
import no.fint.graphql.model.model.skolear.SkolearService;
import no.novari.fint.model.resource.Link;
import no.novari.fint.model.resource.utdanning.kodeverk.SkolearResource;
import no.novari.fint.model.resource.utdanning.timeplan.FagResource;
import no.novari.fint.model.resource.utdanning.vurdering.ElevvurderingResource;
import no.novari.fint.model.resource.utdanning.vurdering.HalvarsfagvurderingResource;
import no.novari.fint.model.resource.utdanning.vurdering.KarakterverdiResource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.graphql.data.method.annotation.SchemaMapping;
import org.springframework.stereotype.Controller;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.concurrent.CompletionStage;

@Controller("modelHalvarsfagvurderingResolver")
public class HalvarsfagvurderingResolver {

    @Autowired
    private ElevvurderingService elevvurderingService;

    @Autowired
    private FagService fagService;

    @Autowired
    private SkolearService skolearService;

    @Autowired
    private KarakterverdiService karakterverdiService;


    @SchemaMapping(typeName = "Halvarsfagvurdering", field = "elevvurdering")
    public CompletionStage<ElevvurderingResource> getElevvurdering(HalvarsfagvurderingResource halvarsfagvurdering, DataFetchingEnvironment dfe) {
        return Flux.fromStream(halvarsfagvurdering.getElevvurdering()
                .stream()
                .map(Link::getHref)
                .map(l -> elevvurderingService.getElevvurderingResource(l, dfe)))
                .flatMap(Mono::flux)
                .next()
                .toFuture();
    }

    @SchemaMapping(typeName = "Halvarsfagvurdering", field = "fag")
    public CompletionStage<FagResource> getFag(HalvarsfagvurderingResource halvarsfagvurdering, DataFetchingEnvironment dfe) {
        return Flux.fromStream(halvarsfagvurdering.getFag()
                .stream()
                .map(Link::getHref)
                .map(l -> fagService.getFagResource(l, dfe)))
                .flatMap(Mono::flux)
                .next()
                .toFuture();
    }

    @SchemaMapping(typeName = "Halvarsfagvurdering", field = "skolear")
    public CompletionStage<SkolearResource> getSkolear(HalvarsfagvurderingResource halvarsfagvurdering, DataFetchingEnvironment dfe) {
        return Flux.fromStream(halvarsfagvurdering.getSkolear()
                .stream()
                .map(Link::getHref)
                .map(l -> skolearService.getSkolearResource(l, dfe)))
                .flatMap(Mono::flux)
                .next()
                .toFuture();
    }

    @SchemaMapping(typeName = "Halvarsfagvurdering", field = "karakter")
    public CompletionStage<KarakterverdiResource> getKarakter(HalvarsfagvurderingResource halvarsfagvurdering, DataFetchingEnvironment dfe) {
        return Flux.fromStream(halvarsfagvurdering.getKarakter()
                .stream()
                .map(Link::getHref)
                .map(l -> karakterverdiService.getKarakterverdiResource(l, dfe)))
                .flatMap(Mono::flux)
                .next()
                .toFuture();
    }

}

