package no.fint.graphql.model.model.person;

import graphql.schema.DataFetchingEnvironment;
import no.fint.graphql.WebClientRequest;
import no.fint.graphql.model.Endpoints;
import java.util.Map;
import no.novari.fint.model.resource.felles.PersonResource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

@Service("modelPersonService")
public class PersonService {
    @Autowired
    private WebClientRequest webClientRequest;
    @Autowired
    private Endpoints endpoints;

    public Mono<PersonResource> getPersonResourceById(String id, String value, DataFetchingEnvironment dfe) {
        return normalize(webClientRequest.get(
            endpoints.getFelles() + "/person/" + id + "/{value}",
            Map.of("value", value), PersonResource.class, dfe));
    }

    public Mono<PersonResource> getPersonResource(String url, DataFetchingEnvironment dfe) {
        return normalize(webClientRequest.get(url, PersonResource.class, dfe));
    }

    private Mono<PersonResource> normalize(Mono<PersonResource> response) {
        return response;
    }
}
