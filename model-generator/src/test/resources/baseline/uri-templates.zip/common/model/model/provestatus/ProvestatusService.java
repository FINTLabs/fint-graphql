package no.fint.graphql.model.model.provestatus;

import graphql.schema.DataFetchingEnvironment;
import no.fint.graphql.WebClientRequest;
import no.fint.graphql.model.Endpoints;
import java.util.Map;
import no.novari.fint.model.resource.utdanning.kodeverk.ProvestatusResource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

@Service("modelProvestatusService")
public class ProvestatusService {
    @Autowired
    private WebClientRequest webClientRequest;
    @Autowired
    private Endpoints endpoints;

    public Mono<ProvestatusResource> getProvestatusResourceById(String id, String value, DataFetchingEnvironment dfe) {
        return normalize(webClientRequest.get(
            endpoints.getUtdanningKodeverk() + "/provestatus/" + id + "/{value}",
            Map.of("value", value), ProvestatusResource.class, dfe));
    }

    public Mono<ProvestatusResource> getProvestatusResource(String url, DataFetchingEnvironment dfe) {
        return normalize(webClientRequest.get(url, ProvestatusResource.class, dfe));
    }

    private Mono<ProvestatusResource> normalize(Mono<ProvestatusResource> response) {
        return response;
    }
}
