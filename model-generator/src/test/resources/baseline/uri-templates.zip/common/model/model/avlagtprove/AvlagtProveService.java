package no.fint.graphql.model.model.avlagtprove;

import graphql.schema.DataFetchingEnvironment;
import no.fint.graphql.WebClientRequest;
import no.fint.graphql.model.Endpoints;
import java.util.Map;
import no.novari.fint.model.resource.utdanning.larling.AvlagtProveResource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

@Service("modelAvlagtProveService")
public class AvlagtProveService {
    @Autowired
    private WebClientRequest webClientRequest;
    @Autowired
    private Endpoints endpoints;

    public Mono<AvlagtProveResource> getAvlagtProveResourceById(String id, String value, DataFetchingEnvironment dfe) {
        return normalize(webClientRequest.get(
            endpoints.getUtdanningLarling() + "/avlagtprove/" + id + "/{value}",
            Map.of("value", value), AvlagtProveResource.class, dfe));
    }

    public Mono<AvlagtProveResource> getAvlagtProveResource(String url, DataFetchingEnvironment dfe) {
        return normalize(webClientRequest.get(url, AvlagtProveResource.class, dfe));
    }

    private Mono<AvlagtProveResource> normalize(Mono<AvlagtProveResource> response) {
        return response;
    }
}
