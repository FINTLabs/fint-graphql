package no.fint.graphql.model.model.elevvurdering;

import graphql.schema.DataFetchingEnvironment;
import no.fint.graphql.WebClientRequest;
import no.fint.graphql.model.Endpoints;
import java.util.Map;
import no.novari.fint.model.resource.utdanning.vurdering.ElevvurderingResource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

@Service("modelElevvurderingService")
public class ElevvurderingService {
    @Autowired
    private WebClientRequest webClientRequest;
    @Autowired
    private Endpoints endpoints;

    public Mono<ElevvurderingResource> getElevvurderingResourceById(String id, String value, DataFetchingEnvironment dfe) {
        return normalize(webClientRequest.get(
            endpoints.getUtdanningVurdering() + "/elevvurdering/" + id + "/{value}",
            Map.of("value", value), ElevvurderingResource.class, dfe));
    }

    public Mono<ElevvurderingResource> getElevvurderingResource(String url, DataFetchingEnvironment dfe) {
        return normalize(webClientRequest.get(url, ElevvurderingResource.class, dfe));
    }

    private Mono<ElevvurderingResource> normalize(Mono<ElevvurderingResource> response) {
        return response;
    }
}
