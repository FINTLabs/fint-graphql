package no.fint.graphql.model.model.fravarsregistrering;

import graphql.schema.DataFetchingEnvironment;
import no.fint.graphql.WebClientRequest;
import no.fint.graphql.model.Endpoints;
import java.util.Map;
import no.novari.fint.model.resource.utdanning.vurdering.FravarsregistreringResource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

@Service("modelFravarsregistreringService")
public class FravarsregistreringService {
    @Autowired
    private WebClientRequest webClientRequest;
    @Autowired
    private Endpoints endpoints;

    public Mono<FravarsregistreringResource> getFravarsregistreringResourceById(String id, String value, DataFetchingEnvironment dfe) {
        return normalize(webClientRequest.get(
            endpoints.getUtdanningVurdering() + "/fravarsregistrering/" + id + "/{value}",
            Map.of("value", value), FravarsregistreringResource.class, dfe));
    }

    public Mono<FravarsregistreringResource> getFravarsregistreringResource(String url, DataFetchingEnvironment dfe) {
        return normalize(webClientRequest.get(url, FravarsregistreringResource.class, dfe));
    }

    private Mono<FravarsregistreringResource> normalize(Mono<FravarsregistreringResource> response) {
        return response;
    }
}
