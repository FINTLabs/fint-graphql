package no.fint.graphql.model.model.landkode;

import graphql.schema.DataFetchingEnvironment;
import no.fint.graphql.WebClientRequest;
import no.fint.graphql.model.Endpoints;
import java.util.Map;
import no.novari.fint.model.resource.felles.kodeverk.iso.LandkodeResource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

@Service("modelLandkodeService")
public class LandkodeService {
    @Autowired
    private WebClientRequest webClientRequest;
    @Autowired
    private Endpoints endpoints;

    public Mono<LandkodeResource> getLandkodeResourceById(String id, String value, DataFetchingEnvironment dfe) {
        return normalize(webClientRequest.get(
            endpoints.getFellesKodeverkIso() + "/landkode/" + id + "/{value}",
            Map.of("value", value), LandkodeResource.class, dfe));
    }

    public Mono<LandkodeResource> getLandkodeResource(String url, DataFetchingEnvironment dfe) {
        return normalize(webClientRequest.get(url, LandkodeResource.class, dfe));
    }

    private Mono<LandkodeResource> normalize(Mono<LandkodeResource> response) {
        return response;
    }
}
