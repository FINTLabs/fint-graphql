package no.fint.graphql.model.model.otstatus;

import graphql.schema.DataFetchingEnvironment;
import no.fint.graphql.WebClientRequest;
import no.fint.graphql.model.Endpoints;
import java.util.Map;
import no.novari.fint.model.resource.utdanning.kodeverk.OtStatusResource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

@Service("modelOtStatusService")
public class OtStatusService {
    @Autowired
    private WebClientRequest webClientRequest;
    @Autowired
    private Endpoints endpoints;

    public Mono<OtStatusResource> getOtStatusResourceById(String id, String value, DataFetchingEnvironment dfe) {
        return normalize(webClientRequest.get(
            endpoints.getUtdanningKodeverk() + "/otstatus/" + id + "/{value}",
            Map.of("value", value), OtStatusResource.class, dfe));
    }

    public Mono<OtStatusResource> getOtStatusResource(String url, DataFetchingEnvironment dfe) {
        return normalize(webClientRequest.get(url, OtStatusResource.class, dfe));
    }

    private Mono<OtStatusResource> normalize(Mono<OtStatusResource> response) {
        return response;
    }
}
