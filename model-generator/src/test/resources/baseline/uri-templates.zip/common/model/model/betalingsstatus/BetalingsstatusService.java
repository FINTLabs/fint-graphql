package no.fint.graphql.model.model.betalingsstatus;

import graphql.schema.DataFetchingEnvironment;
import no.fint.graphql.WebClientRequest;
import no.fint.graphql.model.Endpoints;
import java.util.Map;
import no.novari.fint.model.resource.utdanning.kodeverk.BetalingsstatusResource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

@Service("modelBetalingsstatusService")
public class BetalingsstatusService {
    @Autowired
    private WebClientRequest webClientRequest;
    @Autowired
    private Endpoints endpoints;

    public Mono<BetalingsstatusResource> getBetalingsstatusResourceById(String id, String value, DataFetchingEnvironment dfe) {
        return normalize(webClientRequest.get(
            endpoints.getUtdanningKodeverk() + "/betalingsstatus/" + id + "/{value}",
            Map.of("value", value), BetalingsstatusResource.class, dfe));
    }

    public Mono<BetalingsstatusResource> getBetalingsstatusResource(String url, DataFetchingEnvironment dfe) {
        return normalize(webClientRequest.get(url, BetalingsstatusResource.class, dfe));
    }

    private Mono<BetalingsstatusResource> normalize(Mono<BetalingsstatusResource> response) {
        return response;
    }
}
