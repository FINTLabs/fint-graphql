package no.fint.graphql.model.model.programomrademedlemskap;

import graphql.schema.DataFetchingEnvironment;
import no.fint.graphql.WebClientRequest;
import no.fint.graphql.model.Endpoints;
import java.util.Map;
import no.novari.fint.model.resource.utdanning.utdanningsprogram.ProgramomrademedlemskapResource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

@Service("modelProgramomrademedlemskapService")
public class ProgramomrademedlemskapService {
    @Autowired
    private WebClientRequest webClientRequest;
    @Autowired
    private Endpoints endpoints;

    public Mono<ProgramomrademedlemskapResource> getProgramomrademedlemskapResourceById(String id, String value, DataFetchingEnvironment dfe) {
        return normalize(webClientRequest.get(
            endpoints.getUtdanningUtdanningsprogram() + "/programomrademedlemskap/" + id + "/{value}",
            Map.of("value", value), ProgramomrademedlemskapResource.class, dfe));
    }

    public Mono<ProgramomrademedlemskapResource> getProgramomrademedlemskapResource(String url, DataFetchingEnvironment dfe) {
        return normalize(webClientRequest.get(url, ProgramomrademedlemskapResource.class, dfe));
    }

    private Mono<ProgramomrademedlemskapResource> normalize(Mono<ProgramomrademedlemskapResource> response) {
        return response;
    }
}
