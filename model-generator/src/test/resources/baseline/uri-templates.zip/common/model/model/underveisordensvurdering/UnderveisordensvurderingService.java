package no.fint.graphql.model.model.underveisordensvurdering;

import graphql.schema.DataFetchingEnvironment;
import no.fint.graphql.WebClientRequest;
import no.fint.graphql.model.Endpoints;
import java.util.Map;
import no.novari.fint.model.resource.utdanning.vurdering.UnderveisordensvurderingResource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

@Service("modelUnderveisordensvurderingService")
public class UnderveisordensvurderingService {
    @Autowired
    private WebClientRequest webClientRequest;
    @Autowired
    private Endpoints endpoints;

    public Mono<UnderveisordensvurderingResource> getUnderveisordensvurderingResourceById(String id, String value, DataFetchingEnvironment dfe) {
        return normalize(webClientRequest.get(
            endpoints.getUtdanningVurdering() + "/underveisordensvurdering/" + id + "/{value}",
            Map.of("value", value), UnderveisordensvurderingResource.class, dfe));
    }

    public Mono<UnderveisordensvurderingResource> getUnderveisordensvurderingResource(String url, DataFetchingEnvironment dfe) {
        return normalize(webClientRequest.get(url, UnderveisordensvurderingResource.class, dfe));
    }

    private Mono<UnderveisordensvurderingResource> normalize(Mono<UnderveisordensvurderingResource> response) {
        return response;
    }
}
