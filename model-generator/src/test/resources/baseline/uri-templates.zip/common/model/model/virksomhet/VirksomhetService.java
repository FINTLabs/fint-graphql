package no.fint.graphql.model.model.virksomhet;

import graphql.schema.DataFetchingEnvironment;
import no.fint.graphql.WebClientRequest;
import no.fint.graphql.model.Endpoints;
import java.util.Map;
import no.novari.fint.model.resource.felles.VirksomhetResource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

@Service("modelVirksomhetService")
public class VirksomhetService {
    @Autowired
    private WebClientRequest webClientRequest;
    @Autowired
    private Endpoints endpoints;

    public Mono<VirksomhetResource> getVirksomhetResourceById(String id, String value, DataFetchingEnvironment dfe) {
        return normalize(webClientRequest.get(
            endpoints.getFelles() + "/virksomhet/" + id + "/{value}",
            Map.of("value", value), VirksomhetResource.class, dfe));
    }

    public Mono<VirksomhetResource> getVirksomhetResource(String url, DataFetchingEnvironment dfe) {
        return normalize(webClientRequest.get(url, VirksomhetResource.class, dfe));
    }

    private Mono<VirksomhetResource> normalize(Mono<VirksomhetResource> response) {
        return response;
    }
}
