package no.fint.graphql.model.model.karakterverdi;

import graphql.schema.DataFetchingEnvironment;
import no.fint.graphql.WebClientRequest;
import no.fint.graphql.model.Endpoints;
import java.util.Map;
import no.novari.fint.model.resource.utdanning.vurdering.KarakterverdiResource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

@Service("modelKarakterverdiService")
public class KarakterverdiService {
    @Autowired
    private WebClientRequest webClientRequest;
    @Autowired
    private Endpoints endpoints;

    public Mono<KarakterverdiResource> getKarakterverdiResourceById(String id, String value, DataFetchingEnvironment dfe) {
        return normalize(webClientRequest.get(
            endpoints.getUtdanningVurdering() + "/karakterverdi/" + id + "/{value}",
            Map.of("value", value), KarakterverdiResource.class, dfe));
    }

    public Mono<KarakterverdiResource> getKarakterverdiResource(String url, DataFetchingEnvironment dfe) {
        return normalize(webClientRequest.get(url, KarakterverdiResource.class, dfe));
    }

    private Mono<KarakterverdiResource> normalize(Mono<KarakterverdiResource> response) {
        return response;
    }
}
