package no.fint.graphql.model.model.eksamen;

import graphql.schema.DataFetchingEnvironment;
import no.fint.graphql.WebClientRequest;
import no.fint.graphql.model.Endpoints;
import java.util.Map;
import no.novari.fint.model.resource.utdanning.timeplan.EksamenResource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

@Service("modelEksamenService")
public class EksamenService {
    @Autowired
    private WebClientRequest webClientRequest;
    @Autowired
    private Endpoints endpoints;

    public Mono<EksamenResource> getEksamenResourceById(String id, String value, DataFetchingEnvironment dfe) {
        return normalize(webClientRequest.get(
            endpoints.getUtdanningTimeplan() + "/eksamen/" + id + "/{value}",
            Map.of("value", value), EksamenResource.class, dfe));
    }

    public Mono<EksamenResource> getEksamenResource(String url, DataFetchingEnvironment dfe) {
        return normalize(webClientRequest.get(url, EksamenResource.class, dfe));
    }

    private Mono<EksamenResource> normalize(Mono<EksamenResource> response) {
        return response;
    }
}
