package no.fint.graphql.model.model.klassemedlemskap;

import graphql.schema.DataFetchingEnvironment;
import no.fint.graphql.WebClientRequest;
import no.fint.graphql.model.Endpoints;
import java.util.Map;
import no.novari.fint.model.resource.utdanning.elev.KlassemedlemskapResource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

@Service("modelKlassemedlemskapService")
public class KlassemedlemskapService {
    @Autowired
    private WebClientRequest webClientRequest;
    @Autowired
    private Endpoints endpoints;

    public Mono<KlassemedlemskapResource> getKlassemedlemskapResourceById(String id, String value, DataFetchingEnvironment dfe) {
        return normalize(webClientRequest.get(
            endpoints.getUtdanningElev() + "/klassemedlemskap/" + id + "/{value}",
            Map.of("value", value), KlassemedlemskapResource.class, dfe));
    }

    public Mono<KlassemedlemskapResource> getKlassemedlemskapResource(String url, DataFetchingEnvironment dfe) {
        return normalize(webClientRequest.get(url, KlassemedlemskapResource.class, dfe));
    }

    private Mono<KlassemedlemskapResource> normalize(Mono<KlassemedlemskapResource> response) {
        return response;
    }
}
