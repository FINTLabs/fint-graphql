package no.fint.graphql.model.model.larling;

import graphql.schema.DataFetchingEnvironment;
import no.fint.graphql.WebClientRequest;
import no.fint.graphql.model.Endpoints;
import java.util.Map;
import no.novari.fint.model.resource.utdanning.larling.LarlingResource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

@Service("modelLarlingService")
public class LarlingService {
    @Autowired
    private WebClientRequest webClientRequest;
    @Autowired
    private Endpoints endpoints;

    public Mono<LarlingResource> getLarlingResourceById(String id, String value, DataFetchingEnvironment dfe) {
        return normalize(webClientRequest.get(
            endpoints.getUtdanningLarling() + "/larling/" + id + "/{value}",
            Map.of("value", value), LarlingResource.class, dfe));
    }

    public Mono<LarlingResource> getLarlingResource(String url, DataFetchingEnvironment dfe) {
        return normalize(webClientRequest.get(url, LarlingResource.class, dfe));
    }

    private Mono<LarlingResource> normalize(Mono<LarlingResource> response) {
        return response;
    }
}
