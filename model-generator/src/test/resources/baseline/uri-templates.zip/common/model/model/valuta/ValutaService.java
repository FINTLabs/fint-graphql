package no.fint.graphql.model.model.valuta;

import graphql.schema.DataFetchingEnvironment;
import no.fint.graphql.WebClientRequest;
import no.fint.graphql.model.Endpoints;
import java.util.Map;
import no.novari.fint.model.resource.felles.kodeverk.ValutaResource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

@Service("modelValutaService")
public class ValutaService {
    @Autowired
    private WebClientRequest webClientRequest;
    @Autowired
    private Endpoints endpoints;

    public Mono<ValutaResource> getValutaResourceById(String id, String value, DataFetchingEnvironment dfe) {
        return normalize(webClientRequest.get(
            endpoints.getFellesKodeverk() + "/valuta/" + id + "/{value}",
            Map.of("value", value), ValutaResource.class, dfe));
    }

    public Mono<ValutaResource> getValutaResource(String url, DataFetchingEnvironment dfe) {
        return normalize(webClientRequest.get(url, ValutaResource.class, dfe));
    }

    private Mono<ValutaResource> normalize(Mono<ValutaResource> response) {
        return response;
    }
}
