package no.fint.graphql.model.model.termin;

import graphql.schema.DataFetchingEnvironment;
import no.fint.graphql.WebClientRequest;
import no.fint.graphql.model.Endpoints;
import java.util.Map;
import no.novari.fint.model.resource.utdanning.kodeverk.TerminResource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

@Service("modelTerminService")
public class TerminService {
    @Autowired
    private WebClientRequest webClientRequest;
    @Autowired
    private Endpoints endpoints;

    public Mono<TerminResource> getTerminResourceById(String id, String value, DataFetchingEnvironment dfe) {
        return normalize(webClientRequest.get(
            endpoints.getUtdanningKodeverk() + "/termin/" + id + "/{value}",
            Map.of("value", value), TerminResource.class, dfe));
    }

    public Mono<TerminResource> getTerminResource(String url, DataFetchingEnvironment dfe) {
        return normalize(webClientRequest.get(url, TerminResource.class, dfe));
    }

    private Mono<TerminResource> normalize(Mono<TerminResource> response) {
        return response;
    }
}
