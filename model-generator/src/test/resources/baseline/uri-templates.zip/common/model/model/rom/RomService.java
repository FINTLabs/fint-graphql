package no.fint.graphql.model.model.rom;

import graphql.schema.DataFetchingEnvironment;
import no.fint.graphql.WebClientRequest;
import no.fint.graphql.model.Endpoints;
import java.util.Map;
import no.novari.fint.model.resource.utdanning.timeplan.RomResource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

@Service("modelRomService")
public class RomService {
    @Autowired
    private WebClientRequest webClientRequest;
    @Autowired
    private Endpoints endpoints;

    public Mono<RomResource> getRomResourceById(String id, String value, DataFetchingEnvironment dfe) {
        return normalize(webClientRequest.get(
            endpoints.getUtdanningTimeplan() + "/rom/" + id + "/{value}",
            Map.of("value", value), RomResource.class, dfe));
    }

    public Mono<RomResource> getRomResource(String url, DataFetchingEnvironment dfe) {
        return normalize(webClientRequest.get(url, RomResource.class, dfe));
    }

    private Mono<RomResource> normalize(Mono<RomResource> response) {
        return response;
    }
}
