package no.fint.graphql.model.model.aktivitet;

import graphql.schema.DataFetchingEnvironment;
import no.fint.graphql.WebClientRequest;
import no.fint.graphql.model.Endpoints;
import java.util.Map;
import no.novari.fint.model.resource.administrasjon.kodeverk.AktivitetResource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

@Service("modelAktivitetService")
public class AktivitetService {
    @Autowired
    private WebClientRequest webClientRequest;
    @Autowired
    private Endpoints endpoints;

    public Mono<AktivitetResource> getAktivitetResourceById(String id, String value, DataFetchingEnvironment dfe) {
        return normalize(webClientRequest.get(
            endpoints.getAdministrasjonKodeverk() + "/aktivitet/" + id + "/{value}",
            Map.of("value", value), AktivitetResource.class, dfe));
    }

    public Mono<AktivitetResource> getAktivitetResource(String url, DataFetchingEnvironment dfe) {
        return normalize(webClientRequest.get(url, AktivitetResource.class, dfe));
    }

    private Mono<AktivitetResource> normalize(Mono<AktivitetResource> response) {
        return response;
    }
}
