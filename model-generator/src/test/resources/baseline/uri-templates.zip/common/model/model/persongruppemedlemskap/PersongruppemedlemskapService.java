package no.fint.graphql.model.model.persongruppemedlemskap;

import graphql.schema.DataFetchingEnvironment;
import no.fint.graphql.WebClientRequest;
import no.fint.graphql.model.Endpoints;
import java.util.Map;
import no.novari.fint.model.resource.utdanning.elev.PersongruppemedlemskapResource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

@Service("modelPersongruppemedlemskapService")
public class PersongruppemedlemskapService {
    @Autowired
    private WebClientRequest webClientRequest;
    @Autowired
    private Endpoints endpoints;

    public Mono<PersongruppemedlemskapResource> getPersongruppemedlemskapResourceById(String id, String value, DataFetchingEnvironment dfe) {
        return normalize(webClientRequest.get(
            endpoints.getUtdanningElev() + "/persongruppemedlemskap/" + id + "/{value}",
            Map.of("value", value), PersongruppemedlemskapResource.class, dfe));
    }

    public Mono<PersongruppemedlemskapResource> getPersongruppemedlemskapResource(String url, DataFetchingEnvironment dfe) {
        return normalize(webClientRequest.get(url, PersongruppemedlemskapResource.class, dfe));
    }

    private Mono<PersongruppemedlemskapResource> normalize(Mono<PersongruppemedlemskapResource> response) {
        return response;
    }
}
