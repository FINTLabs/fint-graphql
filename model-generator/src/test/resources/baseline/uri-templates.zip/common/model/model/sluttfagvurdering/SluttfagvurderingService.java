package no.fint.graphql.model.model.sluttfagvurdering;

import graphql.schema.DataFetchingEnvironment;
import no.fint.graphql.WebClientRequest;
import no.fint.graphql.model.Endpoints;
import java.util.Map;
import no.novari.fint.model.resource.utdanning.vurdering.SluttfagvurderingResource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

@Service("modelSluttfagvurderingService")
public class SluttfagvurderingService {
    @Autowired
    private WebClientRequest webClientRequest;
    @Autowired
    private Endpoints endpoints;

    public Mono<SluttfagvurderingResource> getSluttfagvurderingResourceById(String id, String value, DataFetchingEnvironment dfe) {
        return normalize(webClientRequest.get(
            endpoints.getUtdanningVurdering() + "/sluttfagvurdering/" + id + "/{value}",
            Map.of("value", value), SluttfagvurderingResource.class, dfe));
    }

    public Mono<SluttfagvurderingResource> getSluttfagvurderingResource(String url, DataFetchingEnvironment dfe) {
        return normalize(webClientRequest.get(url, SluttfagvurderingResource.class, dfe));
    }

    private Mono<SluttfagvurderingResource> normalize(Mono<SluttfagvurderingResource> response) {
        return response;
    }
}
