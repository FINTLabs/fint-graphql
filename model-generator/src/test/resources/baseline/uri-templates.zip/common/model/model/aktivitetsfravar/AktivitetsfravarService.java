package no.fint.graphql.model.model.aktivitetsfravar;

import graphql.schema.DataFetchingEnvironment;
import no.fint.graphql.WebClientRequest;
import no.fint.graphql.model.Endpoints;
import java.util.Map;
import no.novari.fint.model.resource.utdanning.vurdering.AktivitetsfravarResource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

@Service("modelAktivitetsfravarService")
public class AktivitetsfravarService {
    @Autowired
    private WebClientRequest webClientRequest;
    @Autowired
    private Endpoints endpoints;

    public Mono<AktivitetsfravarResource> getAktivitetsfravarResourceById(String id, String value, DataFetchingEnvironment dfe) {
        return normalize(webClientRequest.get(
            endpoints.getUtdanningVurdering() + "/aktivitetsfravar/" + id + "/{value}",
            Map.of("value", value), AktivitetsfravarResource.class, dfe));
    }

    public Mono<AktivitetsfravarResource> getAktivitetsfravarResource(String url, DataFetchingEnvironment dfe) {
        return normalize(webClientRequest.get(url, AktivitetsfravarResource.class, dfe));
    }

    private Mono<AktivitetsfravarResource> normalize(Mono<AktivitetsfravarResource> response) {
        return response;
    }
}
