package no.fint.graphql.model.model.eksamensgruppemedlemskap;

import graphql.schema.DataFetchingEnvironment;
import no.fint.graphql.WebClientRequest;
import no.fint.graphql.model.Endpoints;
import java.util.Map;
import no.novari.fint.model.resource.utdanning.vurdering.EksamensgruppemedlemskapResource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

@Service("modelEksamensgruppemedlemskapService")
public class EksamensgruppemedlemskapService {
    @Autowired
    private WebClientRequest webClientRequest;
    @Autowired
    private Endpoints endpoints;

    public Mono<EksamensgruppemedlemskapResource> getEksamensgruppemedlemskapResourceById(String id, String value, DataFetchingEnvironment dfe) {
        return normalize(webClientRequest.get(
            endpoints.getUtdanningVurdering() + "/eksamensgruppemedlemskap/" + id + "/{value}",
            Map.of("value", value), EksamensgruppemedlemskapResource.class, dfe));
    }

    public Mono<EksamensgruppemedlemskapResource> getEksamensgruppemedlemskapResource(String url, DataFetchingEnvironment dfe) {
        return normalize(webClientRequest.get(url, EksamensgruppemedlemskapResource.class, dfe));
    }

    private Mono<EksamensgruppemedlemskapResource> normalize(Mono<EksamensgruppemedlemskapResource> response) {
        return response;
    }
}
