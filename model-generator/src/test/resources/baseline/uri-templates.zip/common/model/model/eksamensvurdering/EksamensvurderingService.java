package no.fint.graphql.model.model.eksamensvurdering;

import graphql.schema.DataFetchingEnvironment;
import no.fint.graphql.WebClientRequest;
import no.fint.graphql.model.Endpoints;
import java.util.Map;
import no.novari.fint.model.resource.utdanning.vurdering.EksamensvurderingResource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

@Service("modelEksamensvurderingService")
public class EksamensvurderingService {
    @Autowired
    private WebClientRequest webClientRequest;
    @Autowired
    private Endpoints endpoints;

    public Mono<EksamensvurderingResource> getEksamensvurderingResourceById(String id, String value, DataFetchingEnvironment dfe) {
        return normalize(webClientRequest.get(
            endpoints.getUtdanningVurdering() + "/eksamensvurdering/" + id + "/{value}",
            Map.of("value", value), EksamensvurderingResource.class, dfe));
    }

    public Mono<EksamensvurderingResource> getEksamensvurderingResource(String url, DataFetchingEnvironment dfe) {
        return normalize(webClientRequest.get(url, EksamensvurderingResource.class, dfe));
    }

    private Mono<EksamensvurderingResource> normalize(Mono<EksamensvurderingResource> response) {
        return response;
    }
}
