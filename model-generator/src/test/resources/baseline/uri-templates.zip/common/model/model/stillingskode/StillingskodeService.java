package no.fint.graphql.model.model.stillingskode;

import graphql.schema.DataFetchingEnvironment;
import no.fint.graphql.WebClientRequest;
import no.fint.graphql.model.Endpoints;
import java.util.Map;
import no.novari.fint.model.resource.administrasjon.kodeverk.StillingskodeResource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

@Service("modelStillingskodeService")
public class StillingskodeService {
    @Autowired
    private WebClientRequest webClientRequest;
    @Autowired
    private Endpoints endpoints;

    public Mono<StillingskodeResource> getStillingskodeResourceById(String id, String value, DataFetchingEnvironment dfe) {
        return normalize(webClientRequest.get(
            endpoints.getAdministrasjonKodeverk() + "/stillingskode/" + id + "/{value}",
            Map.of("value", value), StillingskodeResource.class, dfe));
    }

    public Mono<StillingskodeResource> getStillingskodeResource(String url, DataFetchingEnvironment dfe) {
        return normalize(webClientRequest.get(url, StillingskodeResource.class, dfe));
    }

    private Mono<StillingskodeResource> normalize(Mono<StillingskodeResource> response) {
        return response;
    }
}
