package no.fint.graphql.model.model.eksamensform;

import graphql.schema.DataFetchingEnvironment;
import no.fint.graphql.WebClientRequest;
import no.fint.graphql.model.Endpoints;
import java.util.Map;
import no.novari.fint.model.resource.utdanning.kodeverk.EksamensformResource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

@Service("modelEksamensformService")
public class EksamensformService {
    @Autowired
    private WebClientRequest webClientRequest;
    @Autowired
    private Endpoints endpoints;

    public Mono<EksamensformResource> getEksamensformResourceById(String id, String value, DataFetchingEnvironment dfe) {
        return normalize(webClientRequest.get(
            endpoints.getUtdanningKodeverk() + "/eksamensform/" + id + "/{value}",
            Map.of("value", value), EksamensformResource.class, dfe));
    }

    public Mono<EksamensformResource> getEksamensformResource(String url, DataFetchingEnvironment dfe) {
        return normalize(webClientRequest.get(url, EksamensformResource.class, dfe));
    }

    private Mono<EksamensformResource> normalize(Mono<EksamensformResource> response) {
        return response;
    }
}
