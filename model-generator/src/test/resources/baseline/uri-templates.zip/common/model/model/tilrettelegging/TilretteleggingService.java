package no.fint.graphql.model.model.tilrettelegging;

import graphql.schema.DataFetchingEnvironment;
import no.fint.graphql.WebClientRequest;
import no.fint.graphql.model.Endpoints;
import java.util.Map;
import no.novari.fint.model.resource.utdanning.kodeverk.TilretteleggingResource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

@Service("modelTilretteleggingService")
public class TilretteleggingService {
    @Autowired
    private WebClientRequest webClientRequest;
    @Autowired
    private Endpoints endpoints;

    public Mono<TilretteleggingResource> getTilretteleggingResourceById(String id, String value, DataFetchingEnvironment dfe) {
        return normalize(webClientRequest.get(
            endpoints.getUtdanningKodeverk() + "/tilrettelegging/" + id + "/{value}",
            Map.of("value", value), TilretteleggingResource.class, dfe));
    }

    public Mono<TilretteleggingResource> getTilretteleggingResource(String url, DataFetchingEnvironment dfe) {
        return normalize(webClientRequest.get(url, TilretteleggingResource.class, dfe));
    }

    private Mono<TilretteleggingResource> normalize(Mono<TilretteleggingResource> response) {
        return response;
    }
}
