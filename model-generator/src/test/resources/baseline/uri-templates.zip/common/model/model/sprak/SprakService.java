package no.fint.graphql.model.model.sprak;

import graphql.schema.DataFetchingEnvironment;
import no.fint.graphql.WebClientRequest;
import no.fint.graphql.model.Endpoints;
import java.util.Map;
import no.novari.fint.model.resource.felles.kodeverk.iso.SprakResource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

@Service("modelSprakService")
public class SprakService {
    @Autowired
    private WebClientRequest webClientRequest;
    @Autowired
    private Endpoints endpoints;

    public Mono<SprakResource> getSprakResourceById(String id, String value, DataFetchingEnvironment dfe) {
        return normalize(webClientRequest.get(
            endpoints.getFellesKodeverkIso() + "/sprak/" + id + "/{value}",
            Map.of("value", value), SprakResource.class, dfe));
    }

    public Mono<SprakResource> getSprakResource(String url, DataFetchingEnvironment dfe) {
        return normalize(webClientRequest.get(url, SprakResource.class, dfe));
    }

    private Mono<SprakResource> normalize(Mono<SprakResource> response) {
        return response;
    }
}
