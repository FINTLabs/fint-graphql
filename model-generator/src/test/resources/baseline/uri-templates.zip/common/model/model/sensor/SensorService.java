package no.fint.graphql.model.model.sensor;

import graphql.schema.DataFetchingEnvironment;
import no.fint.graphql.WebClientRequest;
import no.fint.graphql.model.Endpoints;
import java.util.Map;
import no.novari.fint.model.resource.utdanning.vurdering.SensorResource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

@Service("modelSensorService")
public class SensorService {
    @Autowired
    private WebClientRequest webClientRequest;
    @Autowired
    private Endpoints endpoints;

    public Mono<SensorResource> getSensorResourceById(String id, String value, DataFetchingEnvironment dfe) {
        return normalize(webClientRequest.get(
            endpoints.getUtdanningVurdering() + "/sensor/" + id + "/{value}",
            Map.of("value", value), SensorResource.class, dfe));
    }

    public Mono<SensorResource> getSensorResource(String url, DataFetchingEnvironment dfe) {
        return normalize(webClientRequest.get(url, SensorResource.class, dfe));
    }

    private Mono<SensorResource> normalize(Mono<SensorResource> response) {
        return response;
    }
}
