package no.fint.graphql.model.model.elevfravar;

import graphql.schema.DataFetchingEnvironment;
import no.fint.graphql.WebClientRequest;
import no.fint.graphql.model.Endpoints;
import java.util.Map;
import no.novari.fint.model.resource.utdanning.vurdering.ElevfravarResource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

@Service("modelElevfravarService")
public class ElevfravarService {
    @Autowired
    private WebClientRequest webClientRequest;
    @Autowired
    private Endpoints endpoints;

    public Mono<ElevfravarResource> getElevfravarResourceById(String id, String value, DataFetchingEnvironment dfe) {
        return normalize(webClientRequest.get(
            endpoints.getUtdanningVurdering() + "/elevfravar/" + id + "/{value}",
            Map.of("value", value), ElevfravarResource.class, dfe));
    }

    public Mono<ElevfravarResource> getElevfravarResource(String url, DataFetchingEnvironment dfe) {
        return normalize(webClientRequest.get(url, ElevfravarResource.class, dfe));
    }

    private Mono<ElevfravarResource> normalize(Mono<ElevfravarResource> response) {
        return response;
    }
}
