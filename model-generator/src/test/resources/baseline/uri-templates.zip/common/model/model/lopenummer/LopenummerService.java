package no.fint.graphql.model.model.lopenummer;

import graphql.schema.DataFetchingEnvironment;
import no.fint.graphql.WebClientRequest;
import no.fint.graphql.model.Endpoints;
import java.util.Map;
import no.novari.fint.model.resource.administrasjon.kodeverk.LopenummerResource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

@Service("modelLopenummerService")
public class LopenummerService {
    @Autowired
    private WebClientRequest webClientRequest;
    @Autowired
    private Endpoints endpoints;

    public Mono<LopenummerResource> getLopenummerResourceById(String id, String value, DataFetchingEnvironment dfe) {
        return normalize(webClientRequest.get(
            endpoints.getAdministrasjonKodeverk() + "/lopenummer/" + id + "/{value}",
            Map.of("value", value), LopenummerResource.class, dfe));
    }

    public Mono<LopenummerResource> getLopenummerResource(String url, DataFetchingEnvironment dfe) {
        return normalize(webClientRequest.get(url, LopenummerResource.class, dfe));
    }

    private Mono<LopenummerResource> normalize(Mono<LopenummerResource> response) {
        return response;
    }
}
