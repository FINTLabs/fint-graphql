package no.fint.graphql.model.model.fagmerknad;

import graphql.schema.DataFetchingEnvironment;
import no.fint.graphql.WebClientRequest;
import no.fint.graphql.model.Endpoints;
import java.util.Map;
import no.novari.fint.model.resource.utdanning.kodeverk.FagmerknadResource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

@Service("modelFagmerknadService")
public class FagmerknadService {
    @Autowired
    private WebClientRequest webClientRequest;
    @Autowired
    private Endpoints endpoints;

    public Mono<FagmerknadResource> getFagmerknadResourceById(String id, String value, DataFetchingEnvironment dfe) {
        return normalize(webClientRequest.get(
            endpoints.getUtdanningKodeverk() + "/fagmerknad/" + id + "/{value}",
            Map.of("value", value), FagmerknadResource.class, dfe));
    }

    public Mono<FagmerknadResource> getFagmerknadResource(String url, DataFetchingEnvironment dfe) {
        return normalize(webClientRequest.get(url, FagmerknadResource.class, dfe));
    }

    private Mono<FagmerknadResource> normalize(Mono<FagmerknadResource> response) {
        return response;
    }
}
