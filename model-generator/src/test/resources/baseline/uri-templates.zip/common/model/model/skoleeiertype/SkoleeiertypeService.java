package no.fint.graphql.model.model.skoleeiertype;

import graphql.schema.DataFetchingEnvironment;
import no.fint.graphql.WebClientRequest;
import no.fint.graphql.model.Endpoints;
import java.util.Map;
import no.novari.fint.model.resource.utdanning.kodeverk.SkoleeiertypeResource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

@Service("modelSkoleeiertypeService")
public class SkoleeiertypeService {
    @Autowired
    private WebClientRequest webClientRequest;
    @Autowired
    private Endpoints endpoints;

    public Mono<SkoleeiertypeResource> getSkoleeiertypeResourceById(String id, String value, DataFetchingEnvironment dfe) {
        return normalize(webClientRequest.get(
            endpoints.getUtdanningKodeverk() + "/skoleeiertype/" + id + "/{value}",
            Map.of("value", value), SkoleeiertypeResource.class, dfe));
    }

    public Mono<SkoleeiertypeResource> getSkoleeiertypeResource(String url, DataFetchingEnvironment dfe) {
        return normalize(webClientRequest.get(url, SkoleeiertypeResource.class, dfe));
    }

    private Mono<SkoleeiertypeResource> normalize(Mono<SkoleeiertypeResource> response) {
        return response;
    }
}
