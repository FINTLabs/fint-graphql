package no.fint.graphql.model.model.fylke;

import graphql.schema.DataFetchingEnvironment;
import no.fint.graphql.WebClientRequest;
import no.fint.graphql.model.Endpoints;
import java.util.Map;
import no.novari.fint.model.resource.felles.kodeverk.FylkeResource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

@Service("modelFylkeService")
public class FylkeService {
    @Autowired
    private WebClientRequest webClientRequest;
    @Autowired
    private Endpoints endpoints;

    public Mono<FylkeResource> getFylkeResourceById(String id, String value, DataFetchingEnvironment dfe) {
        return normalize(webClientRequest.get(
            endpoints.getFellesKodeverk() + "/fylke/" + id + "/{value}",
            Map.of("value", value), FylkeResource.class, dfe));
    }

    public Mono<FylkeResource> getFylkeResource(String url, DataFetchingEnvironment dfe) {
        return normalize(webClientRequest.get(url, FylkeResource.class, dfe));
    }

    private Mono<FylkeResource> normalize(Mono<FylkeResource> response) {
        return response;
    }
}
