package no.fint.graphql.model.model.kontrakt;

import graphql.schema.DataFetchingEnvironment;
import no.fint.graphql.WebClientRequest;
import no.fint.graphql.model.Endpoints;
import java.util.Map;
import no.novari.fint.model.resource.administrasjon.kodeverk.KontraktResource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

@Service("modelKontraktService")
public class KontraktService {
    @Autowired
    private WebClientRequest webClientRequest;
    @Autowired
    private Endpoints endpoints;

    public Mono<KontraktResource> getKontraktResourceById(String id, String value, DataFetchingEnvironment dfe) {
        return normalize(webClientRequest.get(
            endpoints.getAdministrasjonKodeverk() + "/kontrakt/" + id + "/{value}",
            Map.of("value", value), KontraktResource.class, dfe));
    }

    public Mono<KontraktResource> getKontraktResource(String url, DataFetchingEnvironment dfe) {
        return normalize(webClientRequest.get(url, KontraktResource.class, dfe));
    }

    private Mono<KontraktResource> normalize(Mono<KontraktResource> response) {
        return response;
    }
}
