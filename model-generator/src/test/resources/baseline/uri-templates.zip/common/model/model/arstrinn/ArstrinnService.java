package no.fint.graphql.model.model.arstrinn;

import graphql.schema.DataFetchingEnvironment;
import no.fint.graphql.WebClientRequest;
import no.fint.graphql.model.Endpoints;
import java.util.Map;
import no.novari.fint.model.resource.utdanning.utdanningsprogram.ArstrinnResource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

@Service("modelArstrinnService")
public class ArstrinnService {
    @Autowired
    private WebClientRequest webClientRequest;
    @Autowired
    private Endpoints endpoints;

    public Mono<ArstrinnResource> getArstrinnResourceById(String id, String value, DataFetchingEnvironment dfe) {
        return normalize(webClientRequest.get(
            endpoints.getUtdanningUtdanningsprogram() + "/arstrinn/" + id + "/{value}",
            Map.of("value", value), ArstrinnResource.class, dfe));
    }

    public Mono<ArstrinnResource> getArstrinnResource(String url, DataFetchingEnvironment dfe) {
        return normalize(webClientRequest.get(url, ArstrinnResource.class, dfe));
    }

    private Mono<ArstrinnResource> normalize(Mono<ArstrinnResource> response) {
        return response;
    }
}
