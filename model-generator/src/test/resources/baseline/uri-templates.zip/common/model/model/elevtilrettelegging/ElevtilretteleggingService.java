package no.fint.graphql.model.model.elevtilrettelegging;

import graphql.schema.DataFetchingEnvironment;
import no.fint.graphql.WebClientRequest;
import no.fint.graphql.model.Endpoints;
import java.util.Map;
import no.novari.fint.model.resource.utdanning.elev.ElevtilretteleggingResource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

@Service("modelElevtilretteleggingService")
public class ElevtilretteleggingService {
    @Autowired
    private WebClientRequest webClientRequest;
    @Autowired
    private Endpoints endpoints;

    public Mono<ElevtilretteleggingResource> getElevtilretteleggingResourceById(String id, String value, DataFetchingEnvironment dfe) {
        return normalize(webClientRequest.get(
            endpoints.getUtdanningElev() + "/elevtilrettelegging/" + id + "/{value}",
            Map.of("value", value), ElevtilretteleggingResource.class, dfe));
    }

    public Mono<ElevtilretteleggingResource> getElevtilretteleggingResource(String url, DataFetchingEnvironment dfe) {
        return normalize(webClientRequest.get(url, ElevtilretteleggingResource.class, dfe));
    }

    private Mono<ElevtilretteleggingResource> normalize(Mono<ElevtilretteleggingResource> response) {
        return response;
    }
}
