package no.fint.graphql.model.model.faggruppe;

import graphql.schema.DataFetchingEnvironment;
import no.fint.graphql.WebClientRequest;
import no.fint.graphql.model.Endpoints;
import java.util.Map;
import no.novari.fint.model.resource.utdanning.timeplan.FaggruppeResource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

@Service("modelFaggruppeService")
public class FaggruppeService {
    @Autowired
    private WebClientRequest webClientRequest;
    @Autowired
    private Endpoints endpoints;

    public Mono<FaggruppeResource> getFaggruppeResourceById(String id, String value, DataFetchingEnvironment dfe) {
        return normalize(webClientRequest.get(
            endpoints.getUtdanningTimeplan() + "/faggruppe/" + id + "/{value}",
            Map.of("value", value), FaggruppeResource.class, dfe));
    }

    public Mono<FaggruppeResource> getFaggruppeResource(String url, DataFetchingEnvironment dfe) {
        return normalize(webClientRequest.get(url, FaggruppeResource.class, dfe));
    }

    private Mono<FaggruppeResource> normalize(Mono<FaggruppeResource> response) {
        return response;
    }
}
