package no.fint.graphql.model.model.kommune;

import graphql.schema.DataFetchingEnvironment;
import no.fint.graphql.WebClientRequest;
import no.fint.graphql.model.Endpoints;
import java.util.Map;
import no.novari.fint.model.resource.felles.kodeverk.KommuneResource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

@Service("modelKommuneService")
public class KommuneService {
    @Autowired
    private WebClientRequest webClientRequest;
    @Autowired
    private Endpoints endpoints;

    public Mono<KommuneResource> getKommuneResourceById(String id, String value, DataFetchingEnvironment dfe) {
        return normalize(webClientRequest.get(
            endpoints.getFellesKodeverk() + "/kommune/" + id + "/{value}",
            Map.of("value", value), KommuneResource.class, dfe));
    }

    public Mono<KommuneResource> getKommuneResource(String url, DataFetchingEnvironment dfe) {
        return normalize(webClientRequest.get(url, KommuneResource.class, dfe));
    }

    private Mono<KommuneResource> normalize(Mono<KommuneResource> response) {
        return response;
    }
}
