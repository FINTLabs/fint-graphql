package no.fint.graphql.model.model.brevtype;

import graphql.schema.DataFetchingEnvironment;
import no.fint.graphql.WebClientRequest;
import no.fint.graphql.model.Endpoints;
import java.util.Map;
import no.novari.fint.model.resource.utdanning.kodeverk.BrevtypeResource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

@Service("modelBrevtypeService")
public class BrevtypeService {
    @Autowired
    private WebClientRequest webClientRequest;
    @Autowired
    private Endpoints endpoints;

    public Mono<BrevtypeResource> getBrevtypeResourceById(String id, String value, DataFetchingEnvironment dfe) {
        return normalize(webClientRequest.get(
            endpoints.getUtdanningKodeverk() + "/brevtype/" + id + "/{value}",
            Map.of("value", value), BrevtypeResource.class, dfe));
    }

    public Mono<BrevtypeResource> getBrevtypeResource(String url, DataFetchingEnvironment dfe) {
        return normalize(webClientRequest.get(url, BrevtypeResource.class, dfe));
    }

    private Mono<BrevtypeResource> normalize(Mono<BrevtypeResource> response) {
        return response;
    }
}
