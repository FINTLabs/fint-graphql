package no.fint.graphql.model.model.undervisningsgruppe;

import graphql.schema.DataFetchingEnvironment;
import no.fint.graphql.WebClientRequest;
import no.fint.graphql.model.Endpoints;
import java.util.Map;
import no.novari.fint.model.resource.utdanning.timeplan.UndervisningsgruppeResource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

@Service("modelUndervisningsgruppeService")
public class UndervisningsgruppeService {
    @Autowired
    private WebClientRequest webClientRequest;
    @Autowired
    private Endpoints endpoints;

    public Mono<UndervisningsgruppeResource> getUndervisningsgruppeResourceById(String id, String value, DataFetchingEnvironment dfe) {
        return normalize(webClientRequest.get(
            endpoints.getUtdanningTimeplan() + "/undervisningsgruppe/" + id + "/{value}",
            Map.of("value", value), UndervisningsgruppeResource.class, dfe));
    }

    public Mono<UndervisningsgruppeResource> getUndervisningsgruppeResource(String url, DataFetchingEnvironment dfe) {
        return normalize(webClientRequest.get(url, UndervisningsgruppeResource.class, dfe));
    }

    private Mono<UndervisningsgruppeResource> normalize(Mono<UndervisningsgruppeResource> response) {
        return response;
    }
}
