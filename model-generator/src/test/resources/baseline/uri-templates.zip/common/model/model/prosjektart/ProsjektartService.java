package no.fint.graphql.model.model.prosjektart;

import graphql.schema.DataFetchingEnvironment;
import no.fint.graphql.WebClientRequest;
import no.fint.graphql.model.Endpoints;
import java.util.Map;
import no.novari.fint.model.resource.administrasjon.kodeverk.ProsjektartResource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

@Service("modelProsjektartService")
public class ProsjektartService {
    @Autowired
    private WebClientRequest webClientRequest;
    @Autowired
    private Endpoints endpoints;

    public Mono<ProsjektartResource> getProsjektartResourceById(String id, String value, DataFetchingEnvironment dfe) {
        return normalize(webClientRequest.get(
            endpoints.getAdministrasjonKodeverk() + "/prosjektart/" + id + "/{value}",
            Map.of("value", value), ProsjektartResource.class, dfe));
    }

    public Mono<ProsjektartResource> getProsjektartResource(String url, DataFetchingEnvironment dfe) {
        return normalize(webClientRequest.get(url, ProsjektartResource.class, dfe));
    }

    private Mono<ProsjektartResource> normalize(Mono<ProsjektartResource> response) {
        return response;
    }
}
