package no.fint.graphql.model.model.prosjekt;

import graphql.schema.DataFetchingEnvironment;
import no.fint.graphql.WebClientRequest;
import no.fint.graphql.model.Endpoints;
import java.util.Map;
import no.novari.fint.model.resource.administrasjon.kodeverk.ProsjektResource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

@Service("modelProsjektService")
public class ProsjektService {
    @Autowired
    private WebClientRequest webClientRequest;
    @Autowired
    private Endpoints endpoints;

    public Mono<ProsjektResource> getProsjektResourceById(String id, String value, DataFetchingEnvironment dfe) {
        return normalize(webClientRequest.get(
            endpoints.getAdministrasjonKodeverk() + "/prosjekt/" + id + "/{value}",
            Map.of("value", value), ProsjektResource.class, dfe));
    }

    public Mono<ProsjektResource> getProsjektResource(String url, DataFetchingEnvironment dfe) {
        return normalize(webClientRequest.get(url, ProsjektResource.class, dfe));
    }

    private Mono<ProsjektResource> normalize(Mono<ProsjektResource> response) {
        return response;
    }
}
