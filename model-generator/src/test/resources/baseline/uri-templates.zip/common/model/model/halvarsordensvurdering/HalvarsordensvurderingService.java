package no.fint.graphql.model.model.halvarsordensvurdering;

import graphql.schema.DataFetchingEnvironment;
import no.fint.graphql.WebClientRequest;
import no.fint.graphql.model.Endpoints;
import java.util.Map;
import no.novari.fint.model.resource.utdanning.vurdering.HalvarsordensvurderingResource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

@Service("modelHalvarsordensvurderingService")
public class HalvarsordensvurderingService {
    @Autowired
    private WebClientRequest webClientRequest;
    @Autowired
    private Endpoints endpoints;

    public Mono<HalvarsordensvurderingResource> getHalvarsordensvurderingResourceById(String id, String value, DataFetchingEnvironment dfe) {
        return normalize(webClientRequest.get(
            endpoints.getUtdanningVurdering() + "/halvarsordensvurdering/" + id + "/{value}",
            Map.of("value", value), HalvarsordensvurderingResource.class, dfe));
    }

    public Mono<HalvarsordensvurderingResource> getHalvarsordensvurderingResource(String url, DataFetchingEnvironment dfe) {
        return normalize(webClientRequest.get(url, HalvarsordensvurderingResource.class, dfe));
    }

    private Mono<HalvarsordensvurderingResource> normalize(Mono<HalvarsordensvurderingResource> response) {
        return response;
    }
}
