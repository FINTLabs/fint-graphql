package no.fint.graphql.model.model.skole;

import graphql.schema.DataFetchingEnvironment;
import no.fint.graphql.WebClientRequest;
import no.fint.graphql.model.Endpoints;
import java.util.Map;
import no.novari.fint.model.resource.utdanning.utdanningsprogram.SkoleResource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

@Service("modelSkoleService")
public class SkoleService {
    @Autowired
    private WebClientRequest webClientRequest;
    @Autowired
    private Endpoints endpoints;

    public Mono<SkoleResource> getSkoleResourceById(String id, String value, DataFetchingEnvironment dfe) {
        return normalize(webClientRequest.get(
            endpoints.getUtdanningUtdanningsprogram() + "/skole/" + id + "/{value}",
            Map.of("value", value), SkoleResource.class, dfe));
    }

    public Mono<SkoleResource> getSkoleResource(String url, DataFetchingEnvironment dfe) {
        return normalize(webClientRequest.get(url, SkoleResource.class, dfe));
    }

    private Mono<SkoleResource> normalize(Mono<SkoleResource> response) {
        return response;
    }
}
