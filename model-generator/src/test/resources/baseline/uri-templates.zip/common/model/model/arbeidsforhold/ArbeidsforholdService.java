package no.fint.graphql.model.model.arbeidsforhold;

import graphql.schema.DataFetchingEnvironment;
import no.fint.graphql.WebClientRequest;
import no.fint.graphql.model.Endpoints;
import java.util.Map;
import no.novari.fint.model.resource.administrasjon.personal.ArbeidsforholdResource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

@Service("modelArbeidsforholdService")
public class ArbeidsforholdService {
    @Autowired
    private WebClientRequest webClientRequest;
    @Autowired
    private Endpoints endpoints;

    public Mono<ArbeidsforholdResource> getArbeidsforholdResourceById(String id, String value, DataFetchingEnvironment dfe) {
        return normalize(webClientRequest.get(
            endpoints.getAdministrasjonPersonal() + "/arbeidsforhold/" + id + "/{value}",
            Map.of("value", value), ArbeidsforholdResource.class, dfe));
    }

    public Mono<ArbeidsforholdResource> getArbeidsforholdResource(String url, DataFetchingEnvironment dfe) {
        return normalize(webClientRequest.get(url, ArbeidsforholdResource.class, dfe));
    }

    private Mono<ArbeidsforholdResource> normalize(Mono<ArbeidsforholdResource> response) {
        return response;
    }
}
