package no.fint.graphql.model.model.varsel;

import graphql.schema.DataFetchingEnvironment;
import no.fint.graphql.WebClientRequest;
import no.fint.graphql.model.Endpoints;
import java.util.Map;
import no.novari.fint.model.resource.utdanning.elev.VarselResource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

@Service("modelVarselService")
public class VarselService {
    @Autowired
    private WebClientRequest webClientRequest;
    @Autowired
    private Endpoints endpoints;

    public Mono<VarselResource> getVarselResourceById(String id, String value, DataFetchingEnvironment dfe) {
        return normalize(webClientRequest.get(
            endpoints.getUtdanningElev() + "/varsel/" + id + "/{value}",
            Map.of("value", value), VarselResource.class, dfe));
    }

    public Mono<VarselResource> getVarselResource(String url, DataFetchingEnvironment dfe) {
        return normalize(webClientRequest.get(url, VarselResource.class, dfe));
    }

    private Mono<VarselResource> normalize(Mono<VarselResource> response) {
        return response;
    }
}
