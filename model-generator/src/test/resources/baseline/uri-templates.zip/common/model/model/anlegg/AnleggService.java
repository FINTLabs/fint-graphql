package no.fint.graphql.model.model.anlegg;

import graphql.schema.DataFetchingEnvironment;
import no.fint.graphql.WebClientRequest;
import no.fint.graphql.model.Endpoints;
import java.util.Map;
import no.novari.fint.model.resource.administrasjon.kodeverk.AnleggResource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

@Service("modelAnleggService")
public class AnleggService {
    @Autowired
    private WebClientRequest webClientRequest;
    @Autowired
    private Endpoints endpoints;

    public Mono<AnleggResource> getAnleggResourceById(String id, String value, DataFetchingEnvironment dfe) {
        return normalize(webClientRequest.get(
            endpoints.getAdministrasjonKodeverk() + "/anlegg/" + id + "/{value}",
            Map.of("value", value), AnleggResource.class, dfe));
    }

    public Mono<AnleggResource> getAnleggResource(String url, DataFetchingEnvironment dfe) {
        return normalize(webClientRequest.get(url, AnleggResource.class, dfe));
    }

    private Mono<AnleggResource> normalize(Mono<AnleggResource> response) {
        return response;
    }
}
