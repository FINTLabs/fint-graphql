package no.fint.graphql.model.model.fravarsoversikt;

import graphql.schema.DataFetchingEnvironment;
import no.fint.graphql.WebClientRequest;
import no.fint.graphql.model.Endpoints;
import java.util.Map;
import no.novari.fint.model.resource.utdanning.vurdering.FravarsoversiktResource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

@Service("modelFravarsoversiktService")
public class FravarsoversiktService {
    @Autowired
    private WebClientRequest webClientRequest;
    @Autowired
    private Endpoints endpoints;

    public Mono<FravarsoversiktResource> getFravarsoversiktResourceById(String id, String value, DataFetchingEnvironment dfe) {
        return normalize(webClientRequest.get(
            endpoints.getUtdanningVurdering() + "/fravarsoversikt/" + id + "/{value}",
            Map.of("value", value), FravarsoversiktResource.class, dfe));
    }

    public Mono<FravarsoversiktResource> getFravarsoversiktResource(String url, DataFetchingEnvironment dfe) {
        return normalize(webClientRequest.get(url, FravarsoversiktResource.class, dfe));
    }

    private Mono<FravarsoversiktResource> normalize(Mono<FravarsoversiktResource> response) {
        return response;
    }
}
