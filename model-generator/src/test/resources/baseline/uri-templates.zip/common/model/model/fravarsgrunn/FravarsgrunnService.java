package no.fint.graphql.model.model.fravarsgrunn;

import graphql.schema.DataFetchingEnvironment;
import no.fint.graphql.WebClientRequest;
import no.fint.graphql.model.Endpoints;
import java.util.Map;
import no.novari.fint.model.resource.administrasjon.kodeverk.FravarsgrunnResource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

@Service("modelFravarsgrunnService")
public class FravarsgrunnService {
    @Autowired
    private WebClientRequest webClientRequest;
    @Autowired
    private Endpoints endpoints;

    public Mono<FravarsgrunnResource> getFravarsgrunnResourceById(String id, String value, DataFetchingEnvironment dfe) {
        return normalize(webClientRequest.get(
            endpoints.getAdministrasjonKodeverk() + "/fravarsgrunn/" + id + "/{value}",
            Map.of("value", value), FravarsgrunnResource.class, dfe));
    }

    public Mono<FravarsgrunnResource> getFravarsgrunnResource(String url, DataFetchingEnvironment dfe) {
        return normalize(webClientRequest.get(url, FravarsgrunnResource.class, dfe));
    }

    private Mono<FravarsgrunnResource> normalize(Mono<FravarsgrunnResource> response) {
        return response;
    }
}
