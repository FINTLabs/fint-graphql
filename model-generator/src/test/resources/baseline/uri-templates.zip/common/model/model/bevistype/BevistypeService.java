package no.fint.graphql.model.model.bevistype;

import graphql.schema.DataFetchingEnvironment;
import no.fint.graphql.WebClientRequest;
import no.fint.graphql.model.Endpoints;
import java.util.Map;
import no.novari.fint.model.resource.utdanning.kodeverk.BevistypeResource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

@Service("modelBevistypeService")
public class BevistypeService {
    @Autowired
    private WebClientRequest webClientRequest;
    @Autowired
    private Endpoints endpoints;

    public Mono<BevistypeResource> getBevistypeResourceById(String id, String value, DataFetchingEnvironment dfe) {
        return normalize(webClientRequest.get(
            endpoints.getUtdanningKodeverk() + "/bevistype/" + id + "/{value}",
            Map.of("value", value), BevistypeResource.class, dfe));
    }

    public Mono<BevistypeResource> getBevistypeResource(String url, DataFetchingEnvironment dfe) {
        return normalize(webClientRequest.get(url, BevistypeResource.class, dfe));
    }

    private Mono<BevistypeResource> normalize(Mono<BevistypeResource> response) {
        return response;
    }
}
