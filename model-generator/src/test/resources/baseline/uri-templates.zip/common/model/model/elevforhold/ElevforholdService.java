package no.fint.graphql.model.model.elevforhold;

import graphql.schema.DataFetchingEnvironment;
import no.fint.graphql.WebClientRequest;
import no.fint.graphql.model.Endpoints;
import java.util.Map;
import no.novari.fint.model.resource.utdanning.elev.ElevforholdResource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

@Service("modelElevforholdService")
public class ElevforholdService {
    @Autowired
    private WebClientRequest webClientRequest;
    @Autowired
    private Endpoints endpoints;

    public Mono<ElevforholdResource> getElevforholdResourceById(String id, String value, DataFetchingEnvironment dfe) {
        return normalize(webClientRequest.get(
            endpoints.getUtdanningElev() + "/elevforhold/" + id + "/{value}",
            Map.of("value", value), ElevforholdResource.class, dfe));
    }

    public Mono<ElevforholdResource> getElevforholdResource(String url, DataFetchingEnvironment dfe) {
        return normalize(webClientRequest.get(url, ElevforholdResource.class, dfe));
    }

    private Mono<ElevforholdResource> normalize(Mono<ElevforholdResource> response) {
        return response;
    }
}
