package no.fint.graphql.model.model.rolle;

import graphql.schema.DataFetchingEnvironment;
import no.fint.graphql.WebClientRequest;
import no.fint.graphql.model.Endpoints;
import java.util.Map;
import no.novari.fint.model.resource.administrasjon.fullmakt.RolleResource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

@Service("modelRolleService")
public class RolleService {
    @Autowired
    private WebClientRequest webClientRequest;
    @Autowired
    private Endpoints endpoints;

    public Mono<RolleResource> getRolleResourceById(String id, String value, DataFetchingEnvironment dfe) {
        return normalize(webClientRequest.get(
            endpoints.getAdministrasjonFullmakt() + "/rolle/" + id + "/{value}",
            Map.of("value", value), RolleResource.class, dfe));
    }

    public Mono<RolleResource> getRolleResource(String url, DataFetchingEnvironment dfe) {
        return normalize(webClientRequest.get(url, RolleResource.class, dfe));
    }

    private Mono<RolleResource> normalize(Mono<RolleResource> response) {
        return response;
    }
}
