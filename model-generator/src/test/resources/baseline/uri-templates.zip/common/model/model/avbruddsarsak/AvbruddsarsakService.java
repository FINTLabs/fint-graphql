package no.fint.graphql.model.model.avbruddsarsak;

import graphql.schema.DataFetchingEnvironment;
import no.fint.graphql.WebClientRequest;
import no.fint.graphql.model.Endpoints;
import java.util.Map;
import no.novari.fint.model.resource.utdanning.kodeverk.AvbruddsarsakResource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

@Service("modelAvbruddsarsakService")
public class AvbruddsarsakService {
    @Autowired
    private WebClientRequest webClientRequest;
    @Autowired
    private Endpoints endpoints;

    public Mono<AvbruddsarsakResource> getAvbruddsarsakResourceById(String id, String value, DataFetchingEnvironment dfe) {
        return normalize(webClientRequest.get(
            endpoints.getUtdanningKodeverk() + "/avbruddsarsak/" + id + "/{value}",
            Map.of("value", value), AvbruddsarsakResource.class, dfe));
    }

    public Mono<AvbruddsarsakResource> getAvbruddsarsakResource(String url, DataFetchingEnvironment dfe) {
        return normalize(webClientRequest.get(url, AvbruddsarsakResource.class, dfe));
    }

    private Mono<AvbruddsarsakResource> normalize(Mono<AvbruddsarsakResource> response) {
        return response;
    }
}
