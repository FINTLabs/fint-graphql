package no.fint.graphql.model.model.personalressurs;

import graphql.schema.DataFetchingEnvironment;
import no.fint.graphql.RelationPageFetcher;
import no.fint.graphql.model.model.arbeidsforhold.ArbeidsforholdService;
import no.fint.graphql.model.model.fullmakt.FullmaktService;
import no.fint.graphql.model.model.organisasjonselement.OrganisasjonselementService;
import no.fint.graphql.model.model.person.PersonService;
import no.fint.graphql.model.model.personalressurskategori.PersonalressurskategoriService;
import no.fint.graphql.model.model.skoleressurs.SkoleressursService;
import no.novari.fint.model.resource.Link;
import no.novari.fint.model.resource.administrasjon.fullmakt.FullmaktResource;
import no.novari.fint.model.resource.administrasjon.kodeverk.PersonalressurskategoriResource;
import no.novari.fint.model.resource.administrasjon.organisasjon.OrganisasjonselementResource;
import no.novari.fint.model.resource.administrasjon.personal.ArbeidsforholdResource;
import no.novari.fint.model.resource.administrasjon.personal.PersonalressursResource;
import no.novari.fint.model.resource.felles.PersonResource;
import no.novari.fint.model.resource.utdanning.elev.SkoleressursResource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.graphql.data.method.annotation.SchemaMapping;
import org.springframework.stereotype.Controller;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;
import java.util.stream.Collectors;

@Controller("modelPersonalressursResolver")
public class PersonalressursResolver {
    @Autowired
    private RelationPageFetcher relationPageFetcher;

    @Autowired
    private PersonalressurskategoriService personalressurskategoriService;

    @Autowired
    private ArbeidsforholdService arbeidsforholdService;

    @Autowired
    private PersonService personService;

    @Autowired
    private FullmaktService fullmaktService;

    @Autowired
    private OrganisasjonselementService organisasjonselementService;

    @Autowired
    private SkoleressursService skoleressursService;

    @SchemaMapping(typeName = "Personalressurs", field = "personalressurskategori")
    public CompletionStage<PersonalressurskategoriResource> getPersonalressurskategori(PersonalressursResource personalressurs, DataFetchingEnvironment dfe) {
        return relationPageFetcher.prefetchSingle("Personalressurs", "personalressurskategori", personalressurs.getPersonalressurskategori(), PersonalressurskategoriResource.class, dfe)
                .thenMany(Flux.fromStream(personalressurs.getPersonalressurskategori()
                .stream()
                .map(Link::getHref)
                .map(l -> personalressurskategoriService.getPersonalressurskategoriResource(l, dfe))))
                .flatMap(Mono::flux)
                .next()
                .toFuture();
    }

    @SchemaMapping(typeName = "Personalressurs", field = "arbeidsforhold")
    public CompletionStage<List<ArbeidsforholdResource>> getArbeidsforhold(PersonalressursResource personalressurs, DataFetchingEnvironment dfe) {
        var links = Optional.ofNullable(personalressurs.getArbeidsforhold()).orElseGet(List::of);
        if (links.isEmpty()) {
            return CompletableFuture.completedFuture(List.of());
        }
        return relationPageFetcher.prefetch("Personalressurs", "arbeidsforhold", links, ArbeidsforholdResource.class, dfe)
                .thenMany(Flux.fromIterable(links))
                .map(Link::getHref)
                .flatMapSequential(href -> arbeidsforholdService.getArbeidsforholdResource(href, dfe)
                        .map(Optional::of)
                        .defaultIfEmpty(Optional.empty())
                        .onErrorResume(WebClientResponseException.class,
                                ex -> Mono.just(Optional.empty())),
                        8, 1)
                .collectList()
                .map(list -> list.stream()
                        .map(opt -> opt.orElse(null))
                        .collect(Collectors.toList()))
                .toFuture();
    }

    @SchemaMapping(typeName = "Personalressurs", field = "person")
    public CompletionStage<PersonResource> getPerson(PersonalressursResource personalressurs, DataFetchingEnvironment dfe) {
        return relationPageFetcher.prefetchSingle("Personalressurs", "person", personalressurs.getPerson(), PersonResource.class, dfe)
                .thenMany(Flux.fromStream(personalressurs.getPerson()
                .stream()
                .map(Link::getHref)
                .map(l -> personService.getPersonResource(l, dfe))))
                .flatMap(Mono::flux)
                .next()
                .toFuture();
    }

    @SchemaMapping(typeName = "Personalressurs", field = "stedfortreder")
    public CompletionStage<List<FullmaktResource>> getStedfortreder(PersonalressursResource personalressurs, DataFetchingEnvironment dfe) {
        var links = Optional.ofNullable(personalressurs.getStedfortreder()).orElseGet(List::of);
        if (links.isEmpty()) {
            return CompletableFuture.completedFuture(List.of());
        }
        return relationPageFetcher.prefetch("Personalressurs", "stedfortreder", links, FullmaktResource.class, dfe)
                .thenMany(Flux.fromIterable(links))
                .map(Link::getHref)
                .flatMapSequential(href -> fullmaktService.getFullmaktResource(href, dfe)
                        .map(Optional::of)
                        .defaultIfEmpty(Optional.empty())
                        .onErrorResume(WebClientResponseException.class,
                                ex -> Mono.just(Optional.empty())),
                        8, 1)
                .collectList()
                .map(list -> list.stream()
                        .map(opt -> opt.orElse(null))
                        .collect(Collectors.toList()))
                .toFuture();
    }

    @SchemaMapping(typeName = "Personalressurs", field = "fullmakt")
    public CompletionStage<List<FullmaktResource>> getFullmakt(PersonalressursResource personalressurs, DataFetchingEnvironment dfe) {
        var links = Optional.ofNullable(personalressurs.getFullmakt()).orElseGet(List::of);
        if (links.isEmpty()) {
            return CompletableFuture.completedFuture(List.of());
        }
        return relationPageFetcher.prefetch("Personalressurs", "fullmakt", links, FullmaktResource.class, dfe)
                .thenMany(Flux.fromIterable(links))
                .map(Link::getHref)
                .flatMapSequential(href -> fullmaktService.getFullmaktResource(href, dfe)
                        .map(Optional::of)
                        .defaultIfEmpty(Optional.empty())
                        .onErrorResume(WebClientResponseException.class,
                                ex -> Mono.just(Optional.empty())),
                        8, 1)
                .collectList()
                .map(list -> list.stream()
                        .map(opt -> opt.orElse(null))
                        .collect(Collectors.toList()))
                .toFuture();
    }

    @SchemaMapping(typeName = "Personalressurs", field = "leder")
    public CompletionStage<List<OrganisasjonselementResource>> getLeder(PersonalressursResource personalressurs, DataFetchingEnvironment dfe) {
        var links = Optional.ofNullable(personalressurs.getLeder()).orElseGet(List::of);
        if (links.isEmpty()) {
            return CompletableFuture.completedFuture(List.of());
        }
        return relationPageFetcher.prefetch("Personalressurs", "leder", links, OrganisasjonselementResource.class, dfe)
                .thenMany(Flux.fromIterable(links))
                .map(Link::getHref)
                .flatMapSequential(href -> organisasjonselementService.getOrganisasjonselementResource(href, dfe)
                        .map(Optional::of)
                        .defaultIfEmpty(Optional.empty())
                        .onErrorResume(WebClientResponseException.class,
                                ex -> Mono.just(Optional.empty())),
                        8, 1)
                .collectList()
                .map(list -> list.stream()
                        .map(opt -> opt.orElse(null))
                        .collect(Collectors.toList()))
                .toFuture();
    }

    @SchemaMapping(typeName = "Personalressurs", field = "personalansvar")
    public CompletionStage<List<ArbeidsforholdResource>> getPersonalansvar(PersonalressursResource personalressurs, DataFetchingEnvironment dfe) {
        var links = Optional.ofNullable(personalressurs.getPersonalansvar()).orElseGet(List::of);
        if (links.isEmpty()) {
            return CompletableFuture.completedFuture(List.of());
        }
        return relationPageFetcher.prefetch("Personalressurs", "personalansvar", links, ArbeidsforholdResource.class, dfe)
                .thenMany(Flux.fromIterable(links))
                .map(Link::getHref)
                .flatMapSequential(href -> arbeidsforholdService.getArbeidsforholdResource(href, dfe)
                        .map(Optional::of)
                        .defaultIfEmpty(Optional.empty())
                        .onErrorResume(WebClientResponseException.class,
                                ex -> Mono.just(Optional.empty())),
                        8, 1)
                .collectList()
                .map(list -> list.stream()
                        .map(opt -> opt.orElse(null))
                        .collect(Collectors.toList()))
                .toFuture();
    }

    @SchemaMapping(typeName = "Personalressurs", field = "skoleressurs")
    public CompletionStage<SkoleressursResource> getSkoleressurs(PersonalressursResource personalressurs, DataFetchingEnvironment dfe) {
        return relationPageFetcher.prefetchSingle("Personalressurs", "skoleressurs", personalressurs.getSkoleressurs(), SkoleressursResource.class, dfe)
                .thenMany(Flux.fromStream(personalressurs.getSkoleressurs()
                .stream()
                .map(Link::getHref)
                .map(l -> skoleressursService.getSkoleressursResource(l, dfe))))
                .flatMap(Mono::flux)
                .next()
                .toFuture();
    }

}
