package no.fint.graphql.model.model.eksamensgruppe;

import graphql.schema.DataFetchingEnvironment;
import no.fint.graphql.RelationPageFetcher;
import no.fint.graphql.model.model.eksamen.EksamenService;
import no.fint.graphql.model.model.eksamensform.EksamensformService;
import no.fint.graphql.model.model.eksamensgruppemedlemskap.EksamensgruppemedlemskapService;
import no.fint.graphql.model.model.fag.FagService;
import no.fint.graphql.model.model.sensor.SensorService;
import no.fint.graphql.model.model.skole.SkoleService;
import no.fint.graphql.model.model.skolear.SkolearService;
import no.fint.graphql.model.model.termin.TerminService;
import no.fint.graphql.model.model.undervisningsforhold.UndervisningsforholdService;
import no.novari.fint.model.resource.Link;
import no.novari.fint.model.resource.utdanning.elev.UndervisningsforholdResource;
import no.novari.fint.model.resource.utdanning.kodeverk.EksamensformResource;
import no.novari.fint.model.resource.utdanning.kodeverk.SkolearResource;
import no.novari.fint.model.resource.utdanning.kodeverk.TerminResource;
import no.novari.fint.model.resource.utdanning.timeplan.EksamenResource;
import no.novari.fint.model.resource.utdanning.timeplan.FagResource;
import no.novari.fint.model.resource.utdanning.utdanningsprogram.SkoleResource;
import no.novari.fint.model.resource.utdanning.vurdering.EksamensgruppeResource;
import no.novari.fint.model.resource.utdanning.vurdering.EksamensgruppemedlemskapResource;
import no.novari.fint.model.resource.utdanning.vurdering.SensorResource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.graphql.data.method.annotation.SchemaMapping;
import org.springframework.stereotype.Controller;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;
import java.util.stream.Collectors;

@Controller("modelEksamensgruppeResolver")
public class EksamensgruppeResolver {
    @Autowired
    private RelationPageFetcher relationPageFetcher;

    @Autowired
    private UndervisningsforholdService undervisningsforholdService;

    @Autowired
    private EksamenService eksamenService;

    @Autowired
    private FagService fagService;

    @Autowired
    private SkoleService skoleService;

    @Autowired
    private TerminService terminService;

    @Autowired
    private EksamensformService eksamensformService;

    @Autowired
    private SkolearService skolearService;

    @Autowired
    private EksamensgruppemedlemskapService eksamensgruppemedlemskapService;

    @Autowired
    private SensorService sensorService;

    @SchemaMapping(typeName = "Eksamensgruppe", field = "undervisningsforhold")
    public CompletionStage<List<UndervisningsforholdResource>> getUndervisningsforhold(EksamensgruppeResource eksamensgruppe, DataFetchingEnvironment dfe) {
        var links = Optional.ofNullable(eksamensgruppe.getUndervisningsforhold()).orElseGet(List::of);
        if (links.isEmpty()) {
            return CompletableFuture.completedFuture(List.of());
        }
        return relationPageFetcher.prefetch("Eksamensgruppe", "undervisningsforhold", links, UndervisningsforholdResource.class, dfe)
                .thenMany(Flux.fromIterable(links))
                .map(Link::getHref)
                .flatMapSequential(href -> undervisningsforholdService.getUndervisningsforholdResource(href, dfe)
                        .map(Optional::of)
                        .defaultIfEmpty(Optional.empty())
                        .onErrorResume(WebClientResponseException.class,
                                ex -> Mono.just(Optional.empty())),
                        8, 1)
                .collectList()
                .map(list -> list.stream()
                        .map(opt -> opt.orElse(null))
                        .collect(Collectors.toList()))
                .toFuture();
    }

    @SchemaMapping(typeName = "Eksamensgruppe", field = "eksamen")
    public CompletionStage<EksamenResource> getEksamen(EksamensgruppeResource eksamensgruppe, DataFetchingEnvironment dfe) {
        return relationPageFetcher.prefetchSingle("Eksamensgruppe", "eksamen", eksamensgruppe.getEksamen(), EksamenResource.class, dfe)
                .thenMany(Flux.fromStream(eksamensgruppe.getEksamen()
                .stream()
                .map(Link::getHref)
                .map(l -> eksamenService.getEksamenResource(l, dfe))))
                .flatMap(Mono::flux)
                .next()
                .toFuture();
    }

    @SchemaMapping(typeName = "Eksamensgruppe", field = "fag")
    public CompletionStage<FagResource> getFag(EksamensgruppeResource eksamensgruppe, DataFetchingEnvironment dfe) {
        return relationPageFetcher.prefetchSingle("Eksamensgruppe", "fag", eksamensgruppe.getFag(), FagResource.class, dfe)
                .thenMany(Flux.fromStream(eksamensgruppe.getFag()
                .stream()
                .map(Link::getHref)
                .map(l -> fagService.getFagResource(l, dfe))))
                .flatMap(Mono::flux)
                .next()
                .toFuture();
    }

    @SchemaMapping(typeName = "Eksamensgruppe", field = "skole")
    public CompletionStage<SkoleResource> getSkole(EksamensgruppeResource eksamensgruppe, DataFetchingEnvironment dfe) {
        return relationPageFetcher.prefetchSingle("Eksamensgruppe", "skole", eksamensgruppe.getSkole(), SkoleResource.class, dfe)
                .thenMany(Flux.fromStream(eksamensgruppe.getSkole()
                .stream()
                .map(Link::getHref)
                .map(l -> skoleService.getSkoleResource(l, dfe))))
                .flatMap(Mono::flux)
                .next()
                .toFuture();
    }

    @SchemaMapping(typeName = "Eksamensgruppe", field = "termin")
    public CompletionStage<TerminResource> getTermin(EksamensgruppeResource eksamensgruppe, DataFetchingEnvironment dfe) {
        return relationPageFetcher.prefetchSingle("Eksamensgruppe", "termin", eksamensgruppe.getTermin(), TerminResource.class, dfe)
                .thenMany(Flux.fromStream(eksamensgruppe.getTermin()
                .stream()
                .map(Link::getHref)
                .map(l -> terminService.getTerminResource(l, dfe))))
                .flatMap(Mono::flux)
                .next()
                .toFuture();
    }

    @SchemaMapping(typeName = "Eksamensgruppe", field = "eksamensform")
    public CompletionStage<EksamensformResource> getEksamensform(EksamensgruppeResource eksamensgruppe, DataFetchingEnvironment dfe) {
        return relationPageFetcher.prefetchSingle("Eksamensgruppe", "eksamensform", eksamensgruppe.getEksamensform(), EksamensformResource.class, dfe)
                .thenMany(Flux.fromStream(eksamensgruppe.getEksamensform()
                .stream()
                .map(Link::getHref)
                .map(l -> eksamensformService.getEksamensformResource(l, dfe))))
                .flatMap(Mono::flux)
                .next()
                .toFuture();
    }

    @SchemaMapping(typeName = "Eksamensgruppe", field = "skolear")
    public CompletionStage<SkolearResource> getSkolear(EksamensgruppeResource eksamensgruppe, DataFetchingEnvironment dfe) {
        return relationPageFetcher.prefetchSingle("Eksamensgruppe", "skolear", eksamensgruppe.getSkolear(), SkolearResource.class, dfe)
                .thenMany(Flux.fromStream(eksamensgruppe.getSkolear()
                .stream()
                .map(Link::getHref)
                .map(l -> skolearService.getSkolearResource(l, dfe))))
                .flatMap(Mono::flux)
                .next()
                .toFuture();
    }

    @SchemaMapping(typeName = "Eksamensgruppe", field = "gruppemedlemskap")
    public CompletionStage<List<EksamensgruppemedlemskapResource>> getGruppemedlemskap(EksamensgruppeResource eksamensgruppe, DataFetchingEnvironment dfe) {
        var links = Optional.ofNullable(eksamensgruppe.getGruppemedlemskap()).orElseGet(List::of);
        if (links.isEmpty()) {
            return CompletableFuture.completedFuture(List.of());
        }
        return relationPageFetcher.prefetch("Eksamensgruppe", "gruppemedlemskap", links, EksamensgruppemedlemskapResource.class, dfe)
                .thenMany(Flux.fromIterable(links))
                .map(Link::getHref)
                .flatMapSequential(href -> eksamensgruppemedlemskapService.getEksamensgruppemedlemskapResource(href, dfe)
                        .map(Optional::of)
                        .defaultIfEmpty(Optional.empty())
                        .onErrorResume(WebClientResponseException.class,
                                ex -> Mono.just(Optional.empty())),
                        8, 1)
                .collectList()
                .map(list -> list.stream()
                        .map(opt -> opt.orElse(null))
                        .collect(Collectors.toList()))
                .toFuture();
    }

    @SchemaMapping(typeName = "Eksamensgruppe", field = "sensor")
    public CompletionStage<List<SensorResource>> getSensor(EksamensgruppeResource eksamensgruppe, DataFetchingEnvironment dfe) {
        var links = Optional.ofNullable(eksamensgruppe.getSensor()).orElseGet(List::of);
        if (links.isEmpty()) {
            return CompletableFuture.completedFuture(List.of());
        }
        return relationPageFetcher.prefetch("Eksamensgruppe", "sensor", links, SensorResource.class, dfe)
                .thenMany(Flux.fromIterable(links))
                .map(Link::getHref)
                .flatMapSequential(href -> sensorService.getSensorResource(href, dfe)
                        .map(Optional::of)
                        .defaultIfEmpty(Optional.empty())
                        .onErrorResume(WebClientResponseException.class,
                                ex -> Mono.just(Optional.empty())),
                        8, 1)
                .collectList()
                .map(list -> list.stream()
                        .map(opt -> opt.orElse(null))
                        .collect(Collectors.toList()))
                .toFuture();
    }

}
