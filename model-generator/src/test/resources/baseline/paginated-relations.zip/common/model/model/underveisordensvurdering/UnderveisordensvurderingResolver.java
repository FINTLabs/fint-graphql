package no.fint.graphql.model.model.underveisordensvurdering;

import graphql.schema.DataFetchingEnvironment;
import no.fint.graphql.RelationPageFetcher;
import no.fint.graphql.model.model.elevvurdering.ElevvurderingService;
import no.fint.graphql.model.model.karakterverdi.KarakterverdiService;
import no.fint.graphql.model.model.skolear.SkolearService;
import no.novari.fint.model.resource.Link;
import no.novari.fint.model.resource.utdanning.kodeverk.SkolearResource;
import no.novari.fint.model.resource.utdanning.vurdering.ElevvurderingResource;
import no.novari.fint.model.resource.utdanning.vurdering.KarakterverdiResource;
import no.novari.fint.model.resource.utdanning.vurdering.UnderveisordensvurderingResource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.graphql.data.method.annotation.SchemaMapping;
import org.springframework.stereotype.Controller;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.concurrent.CompletionStage;

@Controller("modelUnderveisordensvurderingResolver")
public class UnderveisordensvurderingResolver {
    @Autowired
    private RelationPageFetcher relationPageFetcher;

    @Autowired
    private ElevvurderingService elevvurderingService;

    @Autowired
    private KarakterverdiService karakterverdiService;

    @Autowired
    private SkolearService skolearService;

    @SchemaMapping(typeName = "Underveisordensvurdering", field = "elevvurdering")
    public CompletionStage<ElevvurderingResource> getElevvurdering(UnderveisordensvurderingResource underveisordensvurdering, DataFetchingEnvironment dfe) {
        return relationPageFetcher.prefetch(underveisordensvurdering.getElevvurdering(), ElevvurderingResource.class, dfe)
                .thenMany(Flux.fromStream(underveisordensvurdering.getElevvurdering()
                .stream()
                .map(Link::getHref)
                .map(l -> elevvurderingService.getElevvurderingResource(l, dfe))))
                .flatMap(Mono::flux)
                .next()
                .toFuture();
    }

    @SchemaMapping(typeName = "Underveisordensvurdering", field = "atferd")
    public CompletionStage<KarakterverdiResource> getAtferd(UnderveisordensvurderingResource underveisordensvurdering, DataFetchingEnvironment dfe) {
        return relationPageFetcher.prefetch(underveisordensvurdering.getAtferd(), KarakterverdiResource.class, dfe)
                .thenMany(Flux.fromStream(underveisordensvurdering.getAtferd()
                .stream()
                .map(Link::getHref)
                .map(l -> karakterverdiService.getKarakterverdiResource(l, dfe))))
                .flatMap(Mono::flux)
                .next()
                .toFuture();
    }

    @SchemaMapping(typeName = "Underveisordensvurdering", field = "orden")
    public CompletionStage<KarakterverdiResource> getOrden(UnderveisordensvurderingResource underveisordensvurdering, DataFetchingEnvironment dfe) {
        return relationPageFetcher.prefetch(underveisordensvurdering.getOrden(), KarakterverdiResource.class, dfe)
                .thenMany(Flux.fromStream(underveisordensvurdering.getOrden()
                .stream()
                .map(Link::getHref)
                .map(l -> karakterverdiService.getKarakterverdiResource(l, dfe))))
                .flatMap(Mono::flux)
                .next()
                .toFuture();
    }

    @SchemaMapping(typeName = "Underveisordensvurdering", field = "skolear")
    public CompletionStage<SkolearResource> getSkolear(UnderveisordensvurderingResource underveisordensvurdering, DataFetchingEnvironment dfe) {
        return relationPageFetcher.prefetch(underveisordensvurdering.getSkolear(), SkolearResource.class, dfe)
                .thenMany(Flux.fromStream(underveisordensvurdering.getSkolear()
                .stream()
                .map(Link::getHref)
                .map(l -> skolearService.getSkolearResource(l, dfe))))
                .flatMap(Mono::flux)
                .next()
                .toFuture();
    }

}
