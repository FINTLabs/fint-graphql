package no.fint.graphql.model.model.halvarsordensvurdering;

import graphql.schema.DataFetchingEnvironment;
import no.fint.graphql.RelationPageFetcher;
import no.fint.graphql.model.model.elevvurdering.ElevvurderingService;
import no.fint.graphql.model.model.karakterverdi.KarakterverdiService;
import no.fint.graphql.model.model.skolear.SkolearService;
import no.novari.fint.model.resource.Link;
import no.novari.fint.model.resource.utdanning.kodeverk.SkolearResource;
import no.novari.fint.model.resource.utdanning.vurdering.ElevvurderingResource;
import no.novari.fint.model.resource.utdanning.vurdering.HalvarsordensvurderingResource;
import no.novari.fint.model.resource.utdanning.vurdering.KarakterverdiResource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.graphql.data.method.annotation.SchemaMapping;
import org.springframework.stereotype.Controller;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.concurrent.CompletionStage;

@Controller("modelHalvarsordensvurderingResolver")
public class HalvarsordensvurderingResolver {
    @Autowired
    private RelationPageFetcher relationPageFetcher;

    @Autowired
    private ElevvurderingService elevvurderingService;

    @Autowired
    private KarakterverdiService karakterverdiService;

    @Autowired
    private SkolearService skolearService;

    @SchemaMapping(typeName = "Halvarsordensvurdering", field = "elevvurdering")
    public CompletionStage<ElevvurderingResource> getElevvurdering(HalvarsordensvurderingResource halvarsordensvurdering, DataFetchingEnvironment dfe) {
        return relationPageFetcher.prefetchSingle("Halvarsordensvurdering", "elevvurdering", halvarsordensvurdering.getElevvurdering(), ElevvurderingResource.class, dfe)
                .thenMany(Flux.fromStream(halvarsordensvurdering.getElevvurdering()
                .stream()
                .map(Link::getHref)
                .map(l -> elevvurderingService.getElevvurderingResource(l, dfe))))
                .flatMap(Mono::flux)
                .next()
                .toFuture();
    }

    @SchemaMapping(typeName = "Halvarsordensvurdering", field = "atferd")
    public CompletionStage<KarakterverdiResource> getAtferd(HalvarsordensvurderingResource halvarsordensvurdering, DataFetchingEnvironment dfe) {
        return relationPageFetcher.prefetchSingle("Halvarsordensvurdering", "atferd", halvarsordensvurdering.getAtferd(), KarakterverdiResource.class, dfe)
                .thenMany(Flux.fromStream(halvarsordensvurdering.getAtferd()
                .stream()
                .map(Link::getHref)
                .map(l -> karakterverdiService.getKarakterverdiResource(l, dfe))))
                .flatMap(Mono::flux)
                .next()
                .toFuture();
    }

    @SchemaMapping(typeName = "Halvarsordensvurdering", field = "orden")
    public CompletionStage<KarakterverdiResource> getOrden(HalvarsordensvurderingResource halvarsordensvurdering, DataFetchingEnvironment dfe) {
        return relationPageFetcher.prefetchSingle("Halvarsordensvurdering", "orden", halvarsordensvurdering.getOrden(), KarakterverdiResource.class, dfe)
                .thenMany(Flux.fromStream(halvarsordensvurdering.getOrden()
                .stream()
                .map(Link::getHref)
                .map(l -> karakterverdiService.getKarakterverdiResource(l, dfe))))
                .flatMap(Mono::flux)
                .next()
                .toFuture();
    }

    @SchemaMapping(typeName = "Halvarsordensvurdering", field = "skolear")
    public CompletionStage<SkolearResource> getSkolear(HalvarsordensvurderingResource halvarsordensvurdering, DataFetchingEnvironment dfe) {
        return relationPageFetcher.prefetchSingle("Halvarsordensvurdering", "skolear", halvarsordensvurdering.getSkolear(), SkolearResource.class, dfe)
                .thenMany(Flux.fromStream(halvarsordensvurdering.getSkolear()
                .stream()
                .map(Link::getHref)
                .map(l -> skolearService.getSkolearResource(l, dfe))))
                .flatMap(Mono::flux)
                .next()
                .toFuture();
    }

}
