package no.fint.graphql.model.model.persongruppemedlemskap;

import graphql.schema.DataFetchingEnvironment;
import no.fint.graphql.RelationPageFetcher;
import no.fint.graphql.model.model.elevforhold.ElevforholdService;
import no.fint.graphql.model.model.persongruppe.PersongruppeService;
import no.novari.fint.model.resource.Link;
import no.novari.fint.model.resource.utdanning.elev.ElevforholdResource;
import no.novari.fint.model.resource.utdanning.elev.PersongruppeResource;
import no.novari.fint.model.resource.utdanning.elev.PersongruppemedlemskapResource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.graphql.data.method.annotation.SchemaMapping;
import org.springframework.stereotype.Controller;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.concurrent.CompletionStage;

@Controller("modelPersongruppemedlemskapResolver")
public class PersongruppemedlemskapResolver {
    @Autowired
    private RelationPageFetcher relationPageFetcher;

    @Autowired
    private ElevforholdService elevforholdService;

    @Autowired
    private PersongruppeService persongruppeService;

    @SchemaMapping(typeName = "Persongruppemedlemskap", field = "elevforhold")
    public CompletionStage<ElevforholdResource> getElevforhold(PersongruppemedlemskapResource persongruppemedlemskap, DataFetchingEnvironment dfe) {
        return relationPageFetcher.prefetch(persongruppemedlemskap.getElevforhold(), ElevforholdResource.class, dfe)
                .thenMany(Flux.fromStream(persongruppemedlemskap.getElevforhold()
                .stream()
                .map(Link::getHref)
                .map(l -> elevforholdService.getElevforholdResource(l, dfe))))
                .flatMap(Mono::flux)
                .next()
                .toFuture();
    }

    @SchemaMapping(typeName = "Persongruppemedlemskap", field = "persongruppe")
    public CompletionStage<PersongruppeResource> getPersongruppe(PersongruppemedlemskapResource persongruppemedlemskap, DataFetchingEnvironment dfe) {
        return relationPageFetcher.prefetch(persongruppemedlemskap.getPersongruppe(), PersongruppeResource.class, dfe)
                .thenMany(Flux.fromStream(persongruppemedlemskap.getPersongruppe()
                .stream()
                .map(Link::getHref)
                .map(l -> persongruppeService.getPersongruppeResource(l, dfe))))
                .flatMap(Mono::flux)
                .next()
                .toFuture();
    }

}
