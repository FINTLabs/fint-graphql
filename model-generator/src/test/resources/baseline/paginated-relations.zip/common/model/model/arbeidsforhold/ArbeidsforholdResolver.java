package no.fint.graphql.model.model.arbeidsforhold;

import graphql.schema.DataFetchingEnvironment;
import no.fint.graphql.RelationPageFetcher;
import no.fint.graphql.model.model.aktivitet.AktivitetService;
import no.fint.graphql.model.model.anlegg.AnleggService;
import no.fint.graphql.model.model.ansvar.AnsvarService;
import no.fint.graphql.model.model.arbeidsforholdstype.ArbeidsforholdstypeService;
import no.fint.graphql.model.model.arbeidslokasjon.ArbeidslokasjonService;
import no.fint.graphql.model.model.art.ArtService;
import no.fint.graphql.model.model.diverse.DiverseService;
import no.fint.graphql.model.model.fastlonn.FastlonnService;
import no.fint.graphql.model.model.fasttillegg.FasttilleggService;
import no.fint.graphql.model.model.formal.FormalService;
import no.fint.graphql.model.model.funksjon.FunksjonService;
import no.fint.graphql.model.model.kontrakt.KontraktService;
import no.fint.graphql.model.model.lopenummer.LopenummerService;
import no.fint.graphql.model.model.objekt.ObjektService;
import no.fint.graphql.model.model.organisasjonselement.OrganisasjonselementService;
import no.fint.graphql.model.model.personalressurs.PersonalressursService;
import no.fint.graphql.model.model.prosjekt.ProsjektService;
import no.fint.graphql.model.model.ramme.RammeService;
import no.fint.graphql.model.model.stillingskode.StillingskodeService;
import no.fint.graphql.model.model.uketimetall.UketimetallService;
import no.fint.graphql.model.model.undervisningsforhold.UndervisningsforholdService;
import no.fint.graphql.model.model.variabellonn.VariabellonnService;
import no.novari.fint.model.resource.Link;
import no.novari.fint.model.resource.administrasjon.kodeverk.*;
import no.novari.fint.model.resource.administrasjon.organisasjon.ArbeidslokasjonResource;
import no.novari.fint.model.resource.administrasjon.organisasjon.OrganisasjonselementResource;
import no.novari.fint.model.resource.administrasjon.personal.*;
import no.novari.fint.model.resource.utdanning.elev.UndervisningsforholdResource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.graphql.data.method.annotation.SchemaMapping;
import org.springframework.stereotype.Controller;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;
import java.util.stream.Collectors;

@Controller("modelArbeidsforholdResolver")
public class ArbeidsforholdResolver {
    @Autowired
    private RelationPageFetcher relationPageFetcher;

    @Autowired
    private AktivitetService aktivitetService;

    @Autowired
    private AnleggService anleggService;

    @Autowired
    private AnsvarService ansvarService;

    @Autowired
    private ArbeidsforholdstypeService arbeidsforholdstypeService;

    @Autowired
    private ArtService artService;

    @Autowired
    private DiverseService diverseService;

    @Autowired
    private FormalService formalService;

    @Autowired
    private FunksjonService funksjonService;

    @Autowired
    private KontraktService kontraktService;

    @Autowired
    private LopenummerService lopenummerService;

    @Autowired
    private ObjektService objektService;

    @Autowired
    private ProsjektService prosjektService;

    @Autowired
    private RammeService rammeService;

    @Autowired
    private StillingskodeService stillingskodeService;

    @Autowired
    private UketimetallService uketimetallService;

    @Autowired
    private ArbeidslokasjonService arbeidslokasjonService;

    @Autowired
    private OrganisasjonselementService organisasjonselementService;

    @Autowired
    private PersonalressursService personalressursService;

    @Autowired
    private FastlonnService fastlonnService;

    @Autowired
    private FasttilleggService fasttilleggService;

    @Autowired
    private VariabellonnService variabellonnService;

    @Autowired
    private UndervisningsforholdService undervisningsforholdService;

    @SchemaMapping(typeName = "Arbeidsforhold", field = "aktivitet")
    public CompletionStage<AktivitetResource> getAktivitet(ArbeidsforholdResource arbeidsforhold, DataFetchingEnvironment dfe) {
        return Flux.fromStream(arbeidsforhold.getAktivitet()
                .stream()
                .map(Link::getHref)
                .map(l -> aktivitetService.getAktivitetResource(l, dfe)))
                .flatMap(Mono::flux)
                .next()
                .toFuture();
    }

    @SchemaMapping(typeName = "Arbeidsforhold", field = "anlegg")
    public CompletionStage<AnleggResource> getAnlegg(ArbeidsforholdResource arbeidsforhold, DataFetchingEnvironment dfe) {
        return Flux.fromStream(arbeidsforhold.getAnlegg()
                .stream()
                .map(Link::getHref)
                .map(l -> anleggService.getAnleggResource(l, dfe)))
                .flatMap(Mono::flux)
                .next()
                .toFuture();
    }

    @SchemaMapping(typeName = "Arbeidsforhold", field = "ansvar")
    public CompletionStage<AnsvarResource> getAnsvar(ArbeidsforholdResource arbeidsforhold, DataFetchingEnvironment dfe) {
        return Flux.fromStream(arbeidsforhold.getAnsvar()
                .stream()
                .map(Link::getHref)
                .map(l -> ansvarService.getAnsvarResource(l, dfe)))
                .flatMap(Mono::flux)
                .next()
                .toFuture();
    }

    @SchemaMapping(typeName = "Arbeidsforhold", field = "arbeidsforholdstype")
    public CompletionStage<ArbeidsforholdstypeResource> getArbeidsforholdstype(ArbeidsforholdResource arbeidsforhold, DataFetchingEnvironment dfe) {
        return Flux.fromStream(arbeidsforhold.getArbeidsforholdstype()
                .stream()
                .map(Link::getHref)
                .map(l -> arbeidsforholdstypeService.getArbeidsforholdstypeResource(l, dfe)))
                .flatMap(Mono::flux)
                .next()
                .toFuture();
    }

    @SchemaMapping(typeName = "Arbeidsforhold", field = "art")
    public CompletionStage<ArtResource> getArt(ArbeidsforholdResource arbeidsforhold, DataFetchingEnvironment dfe) {
        return Flux.fromStream(arbeidsforhold.getArt()
                .stream()
                .map(Link::getHref)
                .map(l -> artService.getArtResource(l, dfe)))
                .flatMap(Mono::flux)
                .next()
                .toFuture();
    }

    @SchemaMapping(typeName = "Arbeidsforhold", field = "diverse")
    public CompletionStage<DiverseResource> getDiverse(ArbeidsforholdResource arbeidsforhold, DataFetchingEnvironment dfe) {
        return Flux.fromStream(arbeidsforhold.getDiverse()
                .stream()
                .map(Link::getHref)
                .map(l -> diverseService.getDiverseResource(l, dfe)))
                .flatMap(Mono::flux)
                .next()
                .toFuture();
    }

    @SchemaMapping(typeName = "Arbeidsforhold", field = "formal")
    public CompletionStage<FormalResource> getFormal(ArbeidsforholdResource arbeidsforhold, DataFetchingEnvironment dfe) {
        return Flux.fromStream(arbeidsforhold.getFormal()
                .stream()
                .map(Link::getHref)
                .map(l -> formalService.getFormalResource(l, dfe)))
                .flatMap(Mono::flux)
                .next()
                .toFuture();
    }

    @SchemaMapping(typeName = "Arbeidsforhold", field = "funksjon")
    public CompletionStage<FunksjonResource> getFunksjon(ArbeidsforholdResource arbeidsforhold, DataFetchingEnvironment dfe) {
        return Flux.fromStream(arbeidsforhold.getFunksjon()
                .stream()
                .map(Link::getHref)
                .map(l -> funksjonService.getFunksjonResource(l, dfe)))
                .flatMap(Mono::flux)
                .next()
                .toFuture();
    }

    @SchemaMapping(typeName = "Arbeidsforhold", field = "kontrakt")
    public CompletionStage<KontraktResource> getKontrakt(ArbeidsforholdResource arbeidsforhold, DataFetchingEnvironment dfe) {
        return Flux.fromStream(arbeidsforhold.getKontrakt()
                .stream()
                .map(Link::getHref)
                .map(l -> kontraktService.getKontraktResource(l, dfe)))
                .flatMap(Mono::flux)
                .next()
                .toFuture();
    }

    @SchemaMapping(typeName = "Arbeidsforhold", field = "lopenummer")
    public CompletionStage<LopenummerResource> getLopenummer(ArbeidsforholdResource arbeidsforhold, DataFetchingEnvironment dfe) {
        return Flux.fromStream(arbeidsforhold.getLopenummer()
                .stream()
                .map(Link::getHref)
                .map(l -> lopenummerService.getLopenummerResource(l, dfe)))
                .flatMap(Mono::flux)
                .next()
                .toFuture();
    }

    @SchemaMapping(typeName = "Arbeidsforhold", field = "objekt")
    public CompletionStage<ObjektResource> getObjekt(ArbeidsforholdResource arbeidsforhold, DataFetchingEnvironment dfe) {
        return Flux.fromStream(arbeidsforhold.getObjekt()
                .stream()
                .map(Link::getHref)
                .map(l -> objektService.getObjektResource(l, dfe)))
                .flatMap(Mono::flux)
                .next()
                .toFuture();
    }

    @SchemaMapping(typeName = "Arbeidsforhold", field = "prosjekt")
    public CompletionStage<ProsjektResource> getProsjekt(ArbeidsforholdResource arbeidsforhold, DataFetchingEnvironment dfe) {
        return Flux.fromStream(arbeidsforhold.getProsjekt()
                .stream()
                .map(Link::getHref)
                .map(l -> prosjektService.getProsjektResource(l, dfe)))
                .flatMap(Mono::flux)
                .next()
                .toFuture();
    }

    @SchemaMapping(typeName = "Arbeidsforhold", field = "ramme")
    public CompletionStage<RammeResource> getRamme(ArbeidsforholdResource arbeidsforhold, DataFetchingEnvironment dfe) {
        return Flux.fromStream(arbeidsforhold.getRamme()
                .stream()
                .map(Link::getHref)
                .map(l -> rammeService.getRammeResource(l, dfe)))
                .flatMap(Mono::flux)
                .next()
                .toFuture();
    }

    @SchemaMapping(typeName = "Arbeidsforhold", field = "stillingskode")
    public CompletionStage<StillingskodeResource> getStillingskode(ArbeidsforholdResource arbeidsforhold, DataFetchingEnvironment dfe) {
        return Flux.fromStream(arbeidsforhold.getStillingskode()
                .stream()
                .map(Link::getHref)
                .map(l -> stillingskodeService.getStillingskodeResource(l, dfe)))
                .flatMap(Mono::flux)
                .next()
                .toFuture();
    }

    @SchemaMapping(typeName = "Arbeidsforhold", field = "timerPerUke")
    public CompletionStage<UketimetallResource> getTimerPerUke(ArbeidsforholdResource arbeidsforhold, DataFetchingEnvironment dfe) {
        return Flux.fromStream(arbeidsforhold.getTimerPerUke()
                .stream()
                .map(Link::getHref)
                .map(l -> uketimetallService.getUketimetallResource(l, dfe)))
                .flatMap(Mono::flux)
                .next()
                .toFuture();
    }

    @SchemaMapping(typeName = "Arbeidsforhold", field = "arbeidslokasjon")
    public CompletionStage<ArbeidslokasjonResource> getArbeidslokasjon(ArbeidsforholdResource arbeidsforhold, DataFetchingEnvironment dfe) {
        return Flux.fromStream(arbeidsforhold.getArbeidslokasjon()
                .stream()
                .map(Link::getHref)
                .map(l -> arbeidslokasjonService.getArbeidslokasjonResource(l, dfe)))
                .flatMap(Mono::flux)
                .next()
                .toFuture();
    }

    @SchemaMapping(typeName = "Arbeidsforhold", field = "arbeidssted")
    public CompletionStage<OrganisasjonselementResource> getArbeidssted(ArbeidsforholdResource arbeidsforhold, DataFetchingEnvironment dfe) {
        return Flux.fromStream(arbeidsforhold.getArbeidssted()
                .stream()
                .map(Link::getHref)
                .map(l -> organisasjonselementService.getOrganisasjonselementResource(l, dfe)))
                .flatMap(Mono::flux)
                .next()
                .toFuture();
    }

    @SchemaMapping(typeName = "Arbeidsforhold", field = "personalleder")
    public CompletionStage<PersonalressursResource> getPersonalleder(ArbeidsforholdResource arbeidsforhold, DataFetchingEnvironment dfe) {
        return Flux.fromStream(arbeidsforhold.getPersonalleder()
                .stream()
                .map(Link::getHref)
                .map(l -> personalressursService.getPersonalressursResource(l, dfe)))
                .flatMap(Mono::flux)
                .next()
                .toFuture();
    }

    @SchemaMapping(typeName = "Arbeidsforhold", field = "fastlonn")
    public CompletionStage<List<FastlonnResource>> getFastlonn(ArbeidsforholdResource arbeidsforhold, DataFetchingEnvironment dfe) {
        var links = Optional.ofNullable(arbeidsforhold.getFastlonn()).orElseGet(List::of);
        if (links.isEmpty()) {
            return CompletableFuture.completedFuture(List.of());
        }
        return relationPageFetcher.prefetch(links, FastlonnResource.class, dfe)
                .thenMany(Flux.fromIterable(links))
                .map(Link::getHref)
                .flatMapSequential(href -> fastlonnService.getFastlonnResource(href, dfe)
                        .map(Optional::of)
                        .defaultIfEmpty(Optional.empty())
                        .onErrorResume(WebClientResponseException.class,
                                ex -> Mono.just(Optional.empty())),
                        8, 1)
                .collectList()
                .map(list -> list.stream()
                        .map(opt -> opt.orElse(null))
                        .collect(Collectors.toList()))
                .toFuture();
    }

    @SchemaMapping(typeName = "Arbeidsforhold", field = "fasttillegg")
    public CompletionStage<List<FasttilleggResource>> getFasttillegg(ArbeidsforholdResource arbeidsforhold, DataFetchingEnvironment dfe) {
        var links = Optional.ofNullable(arbeidsforhold.getFasttillegg()).orElseGet(List::of);
        if (links.isEmpty()) {
            return CompletableFuture.completedFuture(List.of());
        }
        return relationPageFetcher.prefetch(links, FasttilleggResource.class, dfe)
                .thenMany(Flux.fromIterable(links))
                .map(Link::getHref)
                .flatMapSequential(href -> fasttilleggService.getFasttilleggResource(href, dfe)
                        .map(Optional::of)
                        .defaultIfEmpty(Optional.empty())
                        .onErrorResume(WebClientResponseException.class,
                                ex -> Mono.just(Optional.empty())),
                        8, 1)
                .collectList()
                .map(list -> list.stream()
                        .map(opt -> opt.orElse(null))
                        .collect(Collectors.toList()))
                .toFuture();
    }

    @SchemaMapping(typeName = "Arbeidsforhold", field = "variabellonn")
    public CompletionStage<List<VariabellonnResource>> getVariabellonn(ArbeidsforholdResource arbeidsforhold, DataFetchingEnvironment dfe) {
        var links = Optional.ofNullable(arbeidsforhold.getVariabellonn()).orElseGet(List::of);
        if (links.isEmpty()) {
            return CompletableFuture.completedFuture(List.of());
        }
        return relationPageFetcher.prefetch(links, VariabellonnResource.class, dfe)
                .thenMany(Flux.fromIterable(links))
                .map(Link::getHref)
                .flatMapSequential(href -> variabellonnService.getVariabellonnResource(href, dfe)
                        .map(Optional::of)
                        .defaultIfEmpty(Optional.empty())
                        .onErrorResume(WebClientResponseException.class,
                                ex -> Mono.just(Optional.empty())),
                        8, 1)
                .collectList()
                .map(list -> list.stream()
                        .map(opt -> opt.orElse(null))
                        .collect(Collectors.toList()))
                .toFuture();
    }

    @SchemaMapping(typeName = "Arbeidsforhold", field = "personalressurs")
    public CompletionStage<PersonalressursResource> getPersonalressurs(ArbeidsforholdResource arbeidsforhold, DataFetchingEnvironment dfe) {
        return Flux.fromStream(arbeidsforhold.getPersonalressurs()
                .stream()
                .map(Link::getHref)
                .map(l -> personalressursService.getPersonalressursResource(l, dfe)))
                .flatMap(Mono::flux)
                .next()
                .toFuture();
    }

    @SchemaMapping(typeName = "Arbeidsforhold", field = "undervisningsforhold")
    public CompletionStage<UndervisningsforholdResource> getUndervisningsforhold(ArbeidsforholdResource arbeidsforhold, DataFetchingEnvironment dfe) {
        return Flux.fromStream(arbeidsforhold.getUndervisningsforhold()
                .stream()
                .map(Link::getHref)
                .map(l -> undervisningsforholdService.getUndervisningsforholdResource(l, dfe)))
                .flatMap(Mono::flux)
                .next()
                .toFuture();
    }

}
